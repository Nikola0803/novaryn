<?php
/**
 * Plugin Name:       UMBRCOM Content Engine
 * Plugin URI:        https://umbrcom.co.il
 * Description:       Headless backend for the UMBRCOM React storefront — site settings, nav, Series CPT, product/category fields, page builder, REST CORS, and Pelecard checkout (/umbrcom/v1/*).
 * Version:           1.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Velocity72
 * Text Domain:       umbrcom-content-engine
 *
 * =====================================================================
 * WHY THIS FILE LOOKS LIKE THIS (July 2026 incident): the previous
 * main file was accidentally overwritten by a standalone procedural
 * Pelecard module — losing BOTH the plugin header (so WordPress never
 * listed the plugin in wp-admin → Plugins) and the bootstrap below (so
 * none of the includes/ classes ever loaded: settings, nav, series,
 * product fields and checkout were all dead → /umbrcom/v1/* returned
 * rest_no_route). The procedural Pelecard copy was removed:
 * Umbrcom_CE_Pelecard (includes/class-pelecard.php) is the
 * canonical checkout implementation and registers all four routes the
 * storefront calls (/checkout, /pelecard/confirm, /pelecard/notify,
 * /pelecard/status), with credentials managed in wp-admin instead of
 * wp-config constants.
 * =====================================================================
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'UMBRCOM_CE_VERSION', '1.1.0' );
define( 'UMBRCOM_CE_DIR', plugin_dir_path( __FILE__ ) );
define( 'UMBRCOM_CE_URL', plugin_dir_url( __FILE__ ) );

/* ── Load order matters: the field renderer is a dependency of every
 *    metabox/options class, so it comes first. ─────────────────────── */
require_once UMBRCOM_CE_DIR . 'includes/class-field-renderer.php';        // Umbrcom_Fields (static helper, no init)
require_once UMBRCOM_CE_DIR . 'includes/class-admin-assets.php';
require_once UMBRCOM_CE_DIR . 'includes/class-rest-cors.php';
require_once UMBRCOM_CE_DIR . 'includes/class-options-page.php';
require_once UMBRCOM_CE_DIR . 'includes/class-options-rest.php';          // GET /umbrcom/v1/settings
require_once UMBRCOM_CE_DIR . 'includes/class-nav-endpoint.php';          // GET /umbrcom/v1/nav
require_once UMBRCOM_CE_DIR . 'includes/class-cpt-series.php';            // /wp/v2/series
require_once UMBRCOM_CE_DIR . 'includes/class-series-fields-metabox.php';
require_once UMBRCOM_CE_DIR . 'includes/class-category-fields.php';
require_once UMBRCOM_CE_DIR . 'includes/class-product-fields.php';        // Store API extensions.umbrcom block
require_once UMBRCOM_CE_DIR . 'includes/class-product-fields-metabox.php';
require_once UMBRCOM_CE_DIR . 'includes/class-page-builder-metabox.php';
require_once UMBRCOM_CE_DIR . 'includes/class-page-sync.php';
require_once UMBRCOM_CE_DIR . 'includes/class-pelecard.php';              // /umbrcom/v1/checkout + /pelecard/*

/* ── Boot everything on plugins_loaded so WooCommerce classes exist by
 *    the time Pelecard's REST callbacks run. ────────────────────────── */
add_action( 'plugins_loaded', function () {
	Umbrcom_CE_Admin_Assets::init();
	Umbrcom_CE_Rest_Cors::init();
	Umbrcom_CE_Options_Page::init();
	Umbrcom_CE_Options_Rest::init();
	Umbrcom_CE_Nav_Endpoint::init();
	Umbrcom_CE_Series_CPT::init();
	Umbrcom_CE_Series_Fields_Metabox::init();
	Umbrcom_CE_Category_Fields::init();
	Umbrcom_CE_Product_Fields::init();
	Umbrcom_CE_Product_Fields_Metabox::init();
	Umbrcom_CE_Page_Builder_Metabox::init();
	Umbrcom_CE_Page_Sync::init();
	Umbrcom_CE_Pelecard::init();
} );

/* ── Series CPT needs its rewrite rules registered on activation. ───── */
register_activation_hook( __FILE__, function () {
	Umbrcom_CE_Series_CPT::register_post_type();
	flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
