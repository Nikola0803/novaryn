<?php
/**
 * "Site Settings" — one global admin page for everything the header,
 * footer, and TikTok sections need, stored as a single option
 * (`umbrcom_settings`) so nothing about the site's contact info, brand
 * colors, or nav links is hard-coded in the React app.
 *
 * Uses the same bracket-named-input technique as the Page Builder: the
 * whole form is one big `umbrcom_settings[...]` tree, which PHP parses
 * into a ready-to-use nested array in $_POST automatically.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Options_Page {

	const OPTION_KEY = 'umbrcom_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
	}

	public static function add_menu() {
		add_menu_page(
			'הגדרות האתר',
			'הגדרות האתר',
			'manage_options',
			'umbrcom-site-settings',
			array( __CLASS__, 'render' ),
			'dashicons-admin-generic',
			3
		);
	}

	public static function get_settings() {
		$defaults = array(
			'contact' => array(
				'phone'    => '03-620-8197',
				'whatsapp' => '97236208197',
				'email'    => 'office@umbrcom.co.il',
				'address'  => 'רחוב שלמה אבן גבירול 69, תל אביב',
				'social'   => array(),
			),
			'brand'   => array(
				'waterfall_logo'       => 0,
				'waterfall_color'      => '#3ab4f2',
				'ambercom_color'       => '#e8a030',
				'waterfall_hero_video' => 0,
				'ambercom_hero_video'  => 0,
			),
			'header'  => array(
				'nav_links' => array(),
			),
			'tiktok'  => array(
				'waterfall' => array( 'handle' => '1umbrcom', 'videos' => array() ),
				'ambercom'  => array( 'handle' => '1umbrcom', 'videos' => array() ),
			),
			'footer'  => array(
				'about_text' => '',
				'columns'    => array(),
			),
		);

		$saved = get_option( self::OPTION_KEY, array() );
		return is_array( $saved ) ? array_replace_recursive( $defaults, $saved ) : $defaults;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['umbrcom_settings_nonce'] ) && wp_verify_nonce( $_POST['umbrcom_settings_nonce'], 'umbrcom_settings_save' ) ) {
			self::save();
			echo '<div class="notice notice-success"><p>ההגדרות נשמרו.</p></div>';
		}

		if ( isset( $_GET['synced'] ) ) {
			$count = (int) $_GET['synced'];
			echo '<div class="notice notice-success"><p>' . ( $count > 0 ? "נוצרו {$count} עמודים חדשים." : 'כל העמודים כבר קיימים — אין מה ליצור.' ) . '</p></div>';
		}

		$s = self::get_settings();
		?>
		<div class="wrap umbrcom-settings-page umbrcom-rtl" dir="rtl">
			<h1>הגדרות האתר</h1>

			<div class="notice notice-info" style="padding:12px 16px;">
				<p style="margin:0 0 8px">
					<strong>עמודים</strong> (בית, אודות, צור קשר, תקנון, …) מנוהלים תחת
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>">עמודים ← כל העמודים</a>,
					בתיבת <strong>בונה העמודים</strong> של כל עמוד — לא כאן. מסך זה מיועד
					להגדרות כלל־אתריות בלבד (פרטי קשר, צבעי מותג, קישורי ניווט, TikTok, פוטר).
				</p>
				<a
					href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=umbrcom_sync_pages' ), 'umbrcom_sync_pages' ) ); ?>"
					class="button"
				>סנכרון עמודים עכשיו (יוצר עמודים חסרים בלבד — לעולם לא נוגע בקיימים)</a>
			</div>

			<form method="post">
				<?php wp_nonce_field( 'umbrcom_settings_save', 'umbrcom_settings_nonce' ); ?>

				<h2>פרטי קשר ורשתות חברתיות</h2>
				<table class="form-table">
					<tr><th>מספר טלפון</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[contact][phone]', $s['contact']['phone'] ); ?></td></tr>
					<tr><th>מספר WhatsApp (בינלאומי, בלי +)</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[contact][whatsapp]', $s['contact']['whatsapp'] ); ?></td></tr>
					<tr><th>אימייל ליצירת קשר</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[contact][email]', $s['contact']['email'] ); ?></td></tr>
					<tr><th>כתובת</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[contact][address]', $s['contact']['address'] ); ?></td></tr>
					<tr>
						<th>קישורים לרשתות חברתיות</th>
						<td>
							<?php
							Umbrcom_Fields::repeater(
								'umbrcom_settings[contact][social]',
								$s['contact']['social'],
								function ( $base, $i, $row ) {
									Umbrcom_Fields::select( "{$base}[{$i}][platform]", $row['platform'] ?? '', array(
										'facebook' => 'Facebook', 'instagram' => 'Instagram', 'tiktok' => 'TikTok',
										'youtube' => 'YouTube', 'telegram' => 'Telegram', 'whatsapp' => 'WhatsApp',
									), 'Platform' );
									Umbrcom_Fields::url( "{$base}[{$i}][url]", $row['url'] ?? '', 'URL' );
								},
								'+ הוספת קישור חברתי',
								'__L1_INDEX__'
							);
							?>
						</td>
					</tr>
				</table>

				<h2>צבעי מותג ולוגואים</h2>
				<table class="form-table">
					<tr><th>לוגו Waterfall</th><td><?php Umbrcom_Fields::image( 'umbrcom_settings[brand][waterfall_logo]', $s['brand']['waterfall_logo'], '' ); ?></td></tr>
					<tr><th>צבע מותג Waterfall</th><td><?php Umbrcom_Fields::color( 'umbrcom_settings[brand][waterfall_color]', $s['brand']['waterfall_color'] ); ?></td></tr>
					<tr><th>צבע מותג Ambercom</th><td><?php Umbrcom_Fields::color( 'umbrcom_settings[brand][ambercom_color]', $s['brand']['ambercom_color'] ); ?></td></tr>
					<tr><th>וידאו הירו לדף הבית — Waterfall (mp4)</th><td><?php Umbrcom_Fields::file( 'umbrcom_settings[brand][waterfall_hero_video]', $s['brand']['waterfall_hero_video'], '', 'video/mp4' ); ?></td></tr>
					<tr><th>וידאו הירו לדף הבית — Ambercom (mp4)</th><td><?php Umbrcom_Fields::file( 'umbrcom_settings[brand][ambercom_hero_video]', $s['brand']['ambercom_hero_video'], '', 'video/mp4' ); ?></td></tr>
				</table>

				<h2>ניווט בכותרת העליונה</h2>
				<table class="form-table">
					<tr>
						<th>קישורי שורה 2 (מבצעים / מועדון לקוחות / שירות לקוחות)</th>
						<td>
							<?php
							Umbrcom_Fields::repeater(
								'umbrcom_settings[header][nav_links]',
								$s['header']['nav_links'],
								function ( $base, $i, $row ) {
									Umbrcom_Fields::text( "{$base}[{$i}][label]", $row['label'] ?? '', 'תווית' );
									Umbrcom_Fields::text( "{$base}[{$i}][url]", $row['url'] ?? '', 'URL' );
									Umbrcom_Fields::text( "{$base}[{$i}][icon]", $row['icon'] ?? '', 'מחלקת אייקון Remix (למשל ri-price-tag-3-line)' );
								},
								'+ הוספת קישור',
								'__L1_INDEX__'
							);
							?>
						</td>
					</tr>
				</table>

				<h2>מקטעי TikTok</h2>
				<table class="form-table">
					<tr><th>שם משתמש TikTok — Waterfall (בלי @)</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[tiktok][waterfall][handle]', $s['tiktok']['waterfall']['handle'] ); ?></td></tr>
					<tr>
						<th>סרטוני TikTok — Waterfall</th>
						<td>
							<?php
							Umbrcom_Fields::repeater(
								'umbrcom_settings[tiktok][waterfall][videos]',
								$s['tiktok']['waterfall']['videos'],
								function ( $base, $i, $row ) {
									Umbrcom_Fields::text( "{$base}[{$i}][id]", $row['id'] ?? '', 'מזהה סרטון (מתוך ‎tiktok.com/@handle/video/VIDEO_ID‎)' );
									Umbrcom_Fields::text( "{$base}[{$i}][caption]", $row['caption'] ?? '', 'כיתוב' );
								},
								'+ הוספת סרטון',
								'__L1_INDEX__'
							);
							?>
						</td>
					</tr>
					<tr><th>שם משתמש TikTok — Ambercom (בלי @)</th><td><?php Umbrcom_Fields::text( 'umbrcom_settings[tiktok][ambercom][handle]', $s['tiktok']['ambercom']['handle'] ); ?></td></tr>
					<tr>
						<th>סרטוני TikTok — Ambercom</th>
						<td>
							<?php
							Umbrcom_Fields::repeater(
								'umbrcom_settings[tiktok][ambercom][videos]',
								$s['tiktok']['ambercom']['videos'],
								function ( $base, $i, $row ) {
									Umbrcom_Fields::text( "{$base}[{$i}][id]", $row['id'] ?? '', 'מזהה סרטון' );
									Umbrcom_Fields::text( "{$base}[{$i}][caption]", $row['caption'] ?? '', 'כיתוב' );
								},
								'+ הוספת סרטון',
								'__L1_INDEX__'
							);
							?>
						</td>
					</tr>
				</table>

				<h2>פוטר</h2>
				<table class="form-table">
					<tr><th>טקסט אודות / ניוזלטר בפוטר</th><td><?php Umbrcom_Fields::textarea( 'umbrcom_settings[footer][about_text]', $s['footer']['about_text'], '', 3 ); ?></td></tr>
					<tr>
						<th>עמודות קישורים בפוטר</th>
						<td>
							<?php
							Umbrcom_Fields::repeater(
								'umbrcom_settings[footer][columns]',
								$s['footer']['columns'],
								function ( $base, $i, $row ) {
									Umbrcom_Fields::text( "{$base}[{$i}][title]", $row['title'] ?? '', 'כותרת העמודה' );
									Umbrcom_Fields::repeater(
										"{$base}[{$i}][links]",
										$row['links'] ?? array(),
										function ( $base2, $j, $link ) {
											Umbrcom_Fields::text( "{$base2}[{$j}][label]", $link['label'] ?? '', 'תווית' );
											Umbrcom_Fields::text( "{$base2}[{$j}][url]", $link['url'] ?? '', 'URL' );
										},
										'+ הוספת קישור',
										'__L3_INDEX__'
									);
								},
								'+ הוספת עמודה',
								'__L1_INDEX__'
							);
							?>
						</td>
					</tr>
				</table>

				<?php submit_button( 'שמירת הגדרות' ); ?>
			</form>
		</div>
		<?php
	}

	private static function save() {
		$raw = isset( $_POST['umbrcom_settings'] ) && is_array( $_POST['umbrcom_settings'] ) ? wp_unslash( $_POST['umbrcom_settings'] ) : array();

		$clean = array(
			'contact' => array(
				'phone'    => sanitize_text_field( $raw['contact']['phone'] ?? '' ),
				'whatsapp' => preg_replace( '/[^0-9]/', '', $raw['contact']['whatsapp'] ?? '' ),
				'email'    => sanitize_email( $raw['contact']['email'] ?? '' ),
				'address'  => sanitize_text_field( $raw['contact']['address'] ?? '' ),
				'social'   => array(),
			),
			'brand'   => array(
				'waterfall_logo'       => absint( $raw['brand']['waterfall_logo'] ?? 0 ),
				'waterfall_color'      => sanitize_hex_color( $raw['brand']['waterfall_color'] ?? '' ),
				'ambercom_color'       => sanitize_hex_color( $raw['brand']['ambercom_color'] ?? '' ),
				'waterfall_hero_video' => absint( $raw['brand']['waterfall_hero_video'] ?? 0 ),
				'ambercom_hero_video'  => absint( $raw['brand']['ambercom_hero_video'] ?? 0 ),
			),
			'header'  => array( 'nav_links' => array() ),
			'tiktok'  => array(
				'waterfall' => array( 'handle' => sanitize_text_field( $raw['tiktok']['waterfall']['handle'] ?? '' ), 'videos' => array() ),
				'ambercom'  => array( 'handle' => sanitize_text_field( $raw['tiktok']['ambercom']['handle'] ?? '' ), 'videos' => array() ),
			),
			'footer'  => array(
				'about_text' => sanitize_textarea_field( $raw['footer']['about_text'] ?? '' ),
				'columns'    => array(),
			),
		);

		foreach ( (array) ( $raw['contact']['social'] ?? array() ) as $row ) {
			if ( empty( $row['url'] ) ) continue;
			$clean['contact']['social'][] = array(
				'platform' => sanitize_key( $row['platform'] ?? '' ),
				'url'      => esc_url_raw( $row['url'] ?? '' ),
			);
		}

		foreach ( (array) ( $raw['header']['nav_links'] ?? array() ) as $row ) {
			if ( empty( $row['label'] ) ) continue;
			$clean['header']['nav_links'][] = array(
				'label' => sanitize_text_field( $row['label'] ?? '' ),
				'url'   => sanitize_text_field( $row['url'] ?? '' ),
				'icon'  => sanitize_text_field( $row['icon'] ?? '' ),
			);
		}

		foreach ( array( 'waterfall', 'ambercom' ) as $brand_key ) {
			foreach ( (array) ( $raw['tiktok'][ $brand_key ]['videos'] ?? array() ) as $row ) {
				if ( empty( $row['id'] ) ) continue;
				$clean['tiktok'][ $brand_key ]['videos'][] = array(
					'id'      => sanitize_text_field( $row['id'] ?? '' ),
					'caption' => sanitize_text_field( $row['caption'] ?? '' ),
				);
			}
		}

		foreach ( (array) ( $raw['footer']['columns'] ?? array() ) as $col ) {
			$links = array();
			foreach ( (array) ( $col['links'] ?? array() ) as $link ) {
				if ( empty( $link['label'] ) ) continue;
				$links[] = array(
					'label' => sanitize_text_field( $link['label'] ?? '' ),
					'url'   => sanitize_text_field( $link['url'] ?? '' ),
				);
			}
			if ( empty( $col['title'] ) && empty( $links ) ) continue;
			$clean['footer']['columns'][] = array(
				'title' => sanitize_text_field( $col['title'] ?? '' ),
				'links' => $links,
			);
		}

		update_option( self::OPTION_KEY, $clean );
	}
}
