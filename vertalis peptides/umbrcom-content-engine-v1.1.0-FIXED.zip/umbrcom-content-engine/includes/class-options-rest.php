<?php
/**
 * GET /wp-json/umbrcom/v1/settings — the Site Settings option, with
 * attachment IDs (logo, hero videos) resolved to URLs so the frontend
 * doesn't need a second request.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Options_Rest {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route( 'umbrcom/v1', '/settings', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_settings' ),
			'permission_callback' => '__return_true',
		) );
	}

	public static function get_settings() {
		$s = Umbrcom_CE_Options_Page::get_settings();

		$s['brand']['waterfall_logo']       = wp_get_attachment_url( $s['brand']['waterfall_logo'] ) ?: '';
		$s['brand']['waterfall_hero_video']  = wp_get_attachment_url( $s['brand']['waterfall_hero_video'] ) ?: '';
		$s['brand']['ambercom_hero_video']   = wp_get_attachment_url( $s['brand']['ambercom_hero_video'] ) ?: '';

		return new \WP_REST_Response( $s, 200 );
	}
}
