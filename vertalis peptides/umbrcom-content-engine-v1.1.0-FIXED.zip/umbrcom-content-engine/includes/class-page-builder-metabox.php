<?php
/**
 * "Page Builder" meta box on every Page — a from-scratch flexible-content
 * field. Sections are stored as a plain nested PHP array in one postmeta
 * key (`_umbrcom_sections`), which WordPress serializes automatically —
 * no JSON encode/decode needed, because bracket-named form inputs
 * (sections[0][heading], sections[0][perks][2][icon], …) already arrive in
 * $_POST as a fully-parsed nested array. This is the same technique every
 * hand-rolled WordPress repeater has used for years.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Page_Builder_Metabox {

	const META_KEY = '_umbrcom_sections';

	const LAYOUTS = array(
		'page_header'       => 'כותרת עמוד / באנר',
		'hero_video'        => 'הירו — באנר וידאו',
		'trust_strip'       => 'רצועת אמון (שורת הטבות)',
		'categories_grid'   => 'רשת קטגוריות',
		'featured_products' => 'מוצרים מומלצים',
		'testimonials'      => 'המלצות לקוחות',
		'tiktok_section'    => 'מקטע TikTok',
		'articles_section'  => 'מאמרים / הצצה לבלוג',
		'info_tiles'        => 'אריחי מידע (רשת יתרונות / דרכי יצירת קשר)',
		'rich_text'         => 'בלוק טקסט עשיר',
		'cta_banner'        => 'באנר קריאה לפעולה',
	);

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_page', array( __CLASS__, 'save' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_field' ) );
	}

	public static function add_meta_box() {
		add_meta_box(
			'umbrcom_page_builder',
			'בונה העמודים',
			array( __CLASS__, 'render' ),
			'page',
			'normal',
			'high'
		);
	}

	public static function render( $post ) {
		wp_nonce_field( 'umbrcom_page_builder_save', 'umbrcom_page_builder_nonce' );
		$sections = get_post_meta( $post->ID, self::META_KEY, true );
		if ( ! is_array( $sections ) ) {
			$sections = array();
		}
		?>
		<div class="umbrcom-page-builder umbrcom-rtl" data-next-index="<?php echo count( $sections ); ?>">
			<div class="umbrcom-sections-list">
				<?php foreach ( $sections as $i => $section ) : ?>
					<?php self::render_section( $i, $section ); ?>
				<?php endforeach; ?>
			</div>

			<?php foreach ( self::LAYOUTS as $type => $type_label ) : ?>
				<template class="umbrcom-section-template" data-layout="<?php echo esc_attr( $type ); ?>">
					<?php self::render_section( '__L1_INDEX__', array( 'type' => $type ) ); ?>
				</template>
			<?php endforeach; ?>

			<div class="umbrcom-add-section-row">
				<select class="umbrcom-add-section-type">
					<?php foreach ( self::LAYOUTS as $type => $type_label ) : ?>
						<option value="<?php echo esc_attr( $type ); ?>"><?php echo esc_html( $type_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<button type="button" class="button button-primary umbrcom-add-section">+ הוספת מקטע</button>
			</div>
			<p class="description">אין גרירה כאן — סדרו מחדש את המקטעים באמצעות כפתורי ה־↑ / ↓ שבכל מקטע.</p>
		</div>
		<?php
	}

	private static function render_section( $index, $section ) {
		$type = $section['type'] ?? '';
		$prefix = "sections[{$index}]";
		?>
		<div class="umbrcom-section" data-layout="<?php echo esc_attr( $type ); ?>">
			<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[type]" value="<?php echo esc_attr( $type ); ?>" />
			<div class="umbrcom-section-header">
				<strong><?php echo esc_html( self::LAYOUTS[ $type ] ?? $type ); ?></strong>
				<div class="umbrcom-row-controls">
					<button type="button" class="umbrcom-row-up" title="הזזה למעלה">&uarr;</button>
					<button type="button" class="umbrcom-row-down" title="הזזה למטה">&darr;</button>
					<button type="button" class="umbrcom-row-remove" title="הסרה">&times;</button>
				</div>
			</div>
			<div class="umbrcom-section-body">
				<?php self::render_fields_for_type( $type, $prefix, $section ); ?>
			</div>
		</div>
		<?php
	}

	private static function render_fields_for_type( $type, $prefix, $data ) {
		switch ( $type ) {

			case 'page_header':
				Umbrcom_Fields::text( "{$prefix}[icon]", $data['icon'] ?? '', 'מחלקת אייקון Remix (אופציונלי — מוצג בעיגול מעל שורת הפתיח)' );
				Umbrcom_Fields::text( "{$prefix}[eyebrow]", $data['eyebrow'] ?? '', 'שורת פתיח (Eyebrow)' );
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::textarea( "{$prefix}[subheading]", $data['subheading'] ?? '', 'כותרת משנה', 2 );
				break;

			case 'hero_video':
				Umbrcom_Fields::text( "{$prefix}[eyebrow]", $data['eyebrow'] ?? '', 'שורת פתיח (Eyebrow)' );
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::text( "{$prefix}[heading_emphasis]", $data['heading_emphasis'] ?? '', 'כותרת (שורת הדגשה)' );
				Umbrcom_Fields::textarea( "{$prefix}[subheading]", $data['subheading'] ?? '', 'כותרת משנה', 2 );
				Umbrcom_Fields::file( "{$prefix}[video]", $data['video'] ?? '', 'וידאו (mp4)', 'video/mp4' );
				Umbrcom_Fields::image( "{$prefix}[poster_image]", $data['poster_image'] ?? '', 'תמונת פוסטר (גיבוי)' );
				Umbrcom_Fields::text( "{$prefix}[button_1_label]", $data['button_1_label'] ?? '', 'תווית כפתור 1' );
				Umbrcom_Fields::text( "{$prefix}[button_1_link]", $data['button_1_link'] ?? '', 'קישור כפתור 1' );
				Umbrcom_Fields::text( "{$prefix}[button_2_label]", $data['button_2_label'] ?? '', 'תווית כפתור 2' );
				Umbrcom_Fields::text( "{$prefix}[button_2_link]", $data['button_2_link'] ?? '', 'קישור כפתור 2' );
				break;

			case 'trust_strip':
				Umbrcom_Fields::repeater(
					"{$prefix}[perks]",
					$data['perks'] ?? array(),
					function ( $base, $i, $row ) {
						Umbrcom_Fields::text( "{$base}[{$i}][icon]", $row['icon'] ?? '', 'מחלקת אייקון Remix (למשל ri-truck-line)' );
						Umbrcom_Fields::text( "{$base}[{$i}][title]", $row['title'] ?? '', 'כותרת' );
						Umbrcom_Fields::text( "{$base}[{$i}][subtitle]", $row['subtitle'] ?? '', 'כותרת משנה' );
					},
					'+ הוספת הטבה',
					'__L2_INDEX__'
				);
				break;

			case 'categories_grid':
				Umbrcom_Fields::text( "{$prefix}[eyebrow]", $data['eyebrow'] ?? '', 'שורת פתיח (Eyebrow)' );
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				$cat_options = array();
				foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) ) as $term ) {
					$cat_options[ $term->term_id ] = $term->name;
				}
				Umbrcom_Fields::checkbox_list( "{$prefix}[categories]", $data['categories'] ?? array(), $cat_options, 'קטגוריות להצגה' );
				break;

			case 'featured_products':
				Umbrcom_Fields::text( "{$prefix}[eyebrow]", $data['eyebrow'] ?? '', 'שורת פתיח (Eyebrow)' );
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::relationship( "{$prefix}[products]", $data['products'] ?? array(), 'product', 'מוצרים' );
				Umbrcom_Fields::text( "{$prefix}[view_all_link]", $data['view_all_link'] ?? '/shop', 'קישור "לכל המוצרים"' );
				break;

			case 'testimonials':
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::repeater(
					"{$prefix}[items]",
					$data['items'] ?? array(),
					function ( $base, $i, $row ) {
						Umbrcom_Fields::text( "{$base}[{$i}][name]", $row['name'] ?? '', 'שם' );
						Umbrcom_Fields::text( "{$base}[{$i}][role]", $row['role'] ?? '', 'תפקיד / מיקום' );
						Umbrcom_Fields::textarea( "{$base}[{$i}][quote]", $row['quote'] ?? '', 'ציטוט', 3 );
						Umbrcom_Fields::number( "{$base}[{$i}][rating]", $row['rating'] ?? 5, 'דירוג (1–5)', 1, 5 );
						Umbrcom_Fields::image( "{$base}[{$i}][avatar]", $row['avatar'] ?? '', 'תמונת פרופיל' );
					},
					'+ הוספת המלצה',
					'__L2_INDEX__'
				);
				break;

			case 'tiktok_section':
				Umbrcom_Fields::select(
					"{$prefix}[brand]",
					$data['brand'] ?? 'waterfall',
					array( 'waterfall' => 'Waterfall', 'ambercom' => 'Ambercom' ),
					'באיזה מותג להשתמש להגדרות ה־TikTok (מוגדר במסך הגדרות האתר)'
				);
				break;

			case 'articles_section':
				Umbrcom_Fields::text( "{$prefix}[eyebrow]", $data['eyebrow'] ?? 'המגזין', 'שורת פתיח (Eyebrow)' );
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::relationship( "{$prefix}[posts]", $data['posts'] ?? array(), 'post', 'מאמרים (הראשון = כתבה ראשית; השאירו ריק ל־4 הפוסטים האחרונים)' );
				break;

			case 'info_tiles':
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת (אופציונלי)' );
				Umbrcom_Fields::select( "{$prefix}[style]", $data['style'] ?? 'cards', array( 'cards' => 'כרטיסים עם מסגרת (רשת יתרונות)', 'circles' => 'עיגולי אייקונים (דרכי יצירת קשר)' ), 'סגנון' );
				Umbrcom_Fields::repeater(
					"{$prefix}[tiles]",
					$data['tiles'] ?? array(),
					function ( $base, $i, $row ) {
						Umbrcom_Fields::text( "{$base}[{$i}][icon]", $row['icon'] ?? '', 'מחלקת אייקון Remix' );
						Umbrcom_Fields::text( "{$base}[{$i}][title]", $row['title'] ?? '', 'כותרת' );
						Umbrcom_Fields::text( "{$base}[{$i}][text]", $row['text'] ?? '', 'טקסט תיאור (אופציונלי)' );
						Umbrcom_Fields::text( "{$base}[{$i}][linkLabel]", $row['linkLabel'] ?? '', 'תווית קישור (אופציונלי)' );
						Umbrcom_Fields::text( "{$base}[{$i}][linkUrl]", $row['linkUrl'] ?? '', 'כתובת קישור (אופציונלי — למשל ‎tel:‎, ‎mailto:‎, ‎https://wa.me/...‎ או ‎/עמוד)' );
					},
					'+ הוספת אריח',
					'__L2_INDEX__'
				);
				break;

			case 'rich_text':
				Umbrcom_Fields::html_textarea( "{$prefix}[content]", $data['content'] ?? '', 'תוכן' );
				break;

			case 'cta_banner':
				Umbrcom_Fields::text( "{$prefix}[heading]", $data['heading'] ?? '', 'כותרת' );
				Umbrcom_Fields::text( "{$prefix}[subheading]", $data['subheading'] ?? '', 'כותרת משנה' );
				Umbrcom_Fields::text( "{$prefix}[button_label]", $data['button_label'] ?? '', 'תווית כפתור' );
				Umbrcom_Fields::text( "{$prefix}[button_link]", $data['button_link'] ?? '', 'קישור כפתור' );
				Umbrcom_Fields::image( "{$prefix}[background_image]", $data['background_image'] ?? '', 'תמונת רקע' );
				Umbrcom_Fields::select( "{$prefix}[theme]", $data['theme'] ?? 'light', array( 'light' => 'טקסט בהיר (רקע כהה)', 'dark' => 'טקסט כהה (רקע בהיר)' ), 'ערכת טקסט' );
				break;
		}
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['umbrcom_page_builder_nonce'] ) || ! wp_verify_nonce( $_POST['umbrcom_page_builder_nonce'], 'umbrcom_page_builder_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

		$raw = isset( $_POST['sections'] ) && is_array( $_POST['sections'] ) ? wp_unslash( $_POST['sections'] ) : array();
		$clean = array();
		foreach ( $raw as $section ) {
			$clean[] = self::sanitize_section( $section );
		}

		update_post_meta( $post_id, self::META_KEY, $clean );
	}

	private static function sanitize_section( $section ) {
		$out = array( 'type' => sanitize_key( $section['type'] ?? '' ) );

		switch ( $out['type'] ) {
			case 'hero_video':
				foreach ( array( 'eyebrow', 'heading', 'heading_emphasis', 'button_1_label', 'button_1_link', 'button_2_label', 'button_2_link' ) as $k ) {
					$out[ $k ] = sanitize_text_field( $section[ $k ] ?? '' );
				}
				$out['subheading']   = sanitize_textarea_field( $section['subheading'] ?? '' );
				$out['video']        = absint( $section['video'] ?? 0 );
				$out['poster_image'] = absint( $section['poster_image'] ?? 0 );
				break;

			case 'trust_strip':
				$out['perks'] = array();
				foreach ( (array) ( $section['perks'] ?? array() ) as $row ) {
					$out['perks'][] = array(
						'icon'     => sanitize_text_field( $row['icon'] ?? '' ),
						'title'    => sanitize_text_field( $row['title'] ?? '' ),
						'subtitle' => sanitize_text_field( $row['subtitle'] ?? '' ),
					);
				}
				break;

			case 'categories_grid':
				$out['eyebrow']    = sanitize_text_field( $section['eyebrow'] ?? '' );
				$out['heading']    = sanitize_text_field( $section['heading'] ?? '' );
				$out['categories'] = array_map( 'absint', (array) ( $section['categories'] ?? array() ) );
				break;

			case 'featured_products':
				$out['eyebrow']       = sanitize_text_field( $section['eyebrow'] ?? '' );
				$out['heading']       = sanitize_text_field( $section['heading'] ?? '' );
				$out['products']      = array_map( 'absint', (array) ( $section['products'] ?? array() ) );
				$out['view_all_link'] = sanitize_text_field( $section['view_all_link'] ?? '/shop' );
				break;

			case 'testimonials':
				$out['heading'] = sanitize_text_field( $section['heading'] ?? '' );
				$out['items']   = array();
				foreach ( (array) ( $section['items'] ?? array() ) as $row ) {
					$out['items'][] = array(
						'name'   => sanitize_text_field( $row['name'] ?? '' ),
						'role'   => sanitize_text_field( $row['role'] ?? '' ),
						'quote'  => sanitize_textarea_field( $row['quote'] ?? '' ),
						'rating' => min( 5, max( 1, absint( $row['rating'] ?? 5 ) ) ),
						'avatar' => absint( $row['avatar'] ?? 0 ),
					);
				}
				break;

			case 'tiktok_section':
				$out['brand'] = in_array( $section['brand'] ?? '', array( 'waterfall', 'ambercom' ), true ) ? $section['brand'] : 'waterfall';
				break;

			case 'articles_section':
				$out['eyebrow'] = sanitize_text_field( $section['eyebrow'] ?? '' );
				$out['heading'] = sanitize_text_field( $section['heading'] ?? '' );
				$out['posts']   = array_map( 'absint', (array) ( $section['posts'] ?? array() ) );
				break;

			case 'page_header':
				$out['icon']       = sanitize_text_field( $section['icon'] ?? '' );
				$out['eyebrow']    = sanitize_text_field( $section['eyebrow'] ?? '' );
				$out['heading']    = sanitize_text_field( $section['heading'] ?? '' );
				$out['subheading'] = sanitize_textarea_field( $section['subheading'] ?? '' );
				break;

			case 'info_tiles':
				$out['heading'] = sanitize_text_field( $section['heading'] ?? '' );
				$out['style']   = in_array( $section['style'] ?? '', array( 'cards', 'circles' ), true ) ? $section['style'] : 'cards';
				$out['tiles']   = array();
				foreach ( (array) ( $section['tiles'] ?? array() ) as $row ) {
					$out['tiles'][] = array(
						'icon'      => sanitize_text_field( $row['icon'] ?? '' ),
						'title'     => sanitize_text_field( $row['title'] ?? '' ),
						'text'      => sanitize_text_field( $row['text'] ?? '' ),
						'linkLabel' => sanitize_text_field( $row['linkLabel'] ?? '' ),
						'linkUrl'   => sanitize_text_field( $row['linkUrl'] ?? '' ),
					);
				}
				break;

			case 'rich_text':
				$out['content'] = wp_kses_post( $section['content'] ?? '' );
				break;

			case 'cta_banner':
				foreach ( array( 'heading', 'subheading', 'button_label', 'button_link' ) as $k ) {
					$out[ $k ] = sanitize_text_field( $section[ $k ] ?? '' );
				}
				$out['background_image'] = absint( $section['background_image'] ?? 0 );
				$out['theme']            = in_array( $section['theme'] ?? '', array( 'light', 'dark' ), true ) ? $section['theme'] : 'light';
				break;
		}

		return $out;
	}

	/**
	 * Exposes the built sections over REST as fully-resolved data (image/
	 * file IDs turned into URLs, relationship IDs turned into a `resolved`
	 * array of {id, title/name/price/image} so the frontend never has to
	 * make N follow-up requests just to render a page).
	 */
	public static function register_rest_field() {
		register_rest_field( 'page', 'umbrcom_sections', array(
			'get_callback' => array( __CLASS__, 'resolve_sections_for_rest' ),
			'schema'       => null,
		) );
	}

	public static function resolve_sections_for_rest( $post_arr ) {
		$sections = get_post_meta( $post_arr['id'], self::META_KEY, true );
		if ( ! is_array( $sections ) ) {
			return array();
		}

		return array_map( function ( $section ) {
			$resolved = $section;

			foreach ( array( 'poster_image', 'background_image', 'avatar' ) as $img_key ) {
				if ( ! empty( $section[ $img_key ] ) ) {
					$resolved[ $img_key ] = wp_get_attachment_url( $section[ $img_key ] );
				}
			}
			if ( ! empty( $section['video'] ) ) {
				$resolved['video'] = wp_get_attachment_url( $section['video'] );
			}
			if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
				foreach ( $resolved['items'] as &$item ) {
					if ( ! empty( $item['avatar'] ) ) {
						$item['avatar'] = wp_get_attachment_url( $item['avatar'] );
					}
				}
			}

			return $resolved;
		}, $sections );
	}
}
