<?php
/**
 * Adds a "Tile Image" + label override to WooCommerce product category
 * terms, so the homepage Categories Grid (and header dropdown) can use
 * real client photography straight from Products → Categories — no code
 * changes needed to swap a photo (this is the fix for item 2 from the
 * original brief).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Category_Fields {

	public static function init() {
		add_action( 'product_cat_add_form_fields', array( __CLASS__, 'add_form_fields' ) );
		add_action( 'product_cat_edit_form_fields', array( __CLASS__, 'edit_form_fields' ) );
		add_action( 'created_product_cat', array( __CLASS__, 'save' ) );
		add_action( 'edited_product_cat', array( __CLASS__, 'save' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_field' ) );
	}

	public static function add_form_fields() {
		wp_nonce_field( 'umbrcom_category_save', 'umbrcom_category_nonce' );
		?>
		<div class="form-field">
			<label>תמונת אריח</label>
			<?php Umbrcom_Fields::image( 'umbrcom_tile_image', '', '' ); ?>
		</div>
		<div class="form-field">
			<label>דריסת שם תצוגה</label>
			<?php Umbrcom_Fields::text( 'umbrcom_label_override', '', '', 'השאירו ריק כדי להשתמש בשם הקטגוריה' ); ?>
		</div>
		<?php
	}

	public static function edit_form_fields( $term ) {
		wp_nonce_field( 'umbrcom_category_save', 'umbrcom_category_nonce' );
		$image  = get_term_meta( $term->term_id, 'umbrcom_tile_image', true );
		$label  = get_term_meta( $term->term_id, 'umbrcom_label_override', true );
		?>
		<tr class="form-field">
			<th><label>תמונת אריח</label></th>
			<td><?php Umbrcom_Fields::image( 'umbrcom_tile_image', $image, '' ); ?></td>
		</tr>
		<tr class="form-field">
			<th><label>דריסת שם תצוגה</label></th>
			<td><?php Umbrcom_Fields::text( 'umbrcom_label_override', $label, '', 'השאירו ריק כדי להשתמש בשם הקטגוריה' ); ?></td>
		</tr>
		<?php
	}

	public static function save( $term_id ) {
		if ( ! isset( $_POST['umbrcom_category_nonce'] ) || ! wp_verify_nonce( $_POST['umbrcom_category_nonce'], 'umbrcom_category_save' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_product_terms' ) ) {
			return;
		}
		update_term_meta( $term_id, 'umbrcom_tile_image', absint( $_POST['umbrcom_tile_image'] ?? 0 ) );
		update_term_meta( $term_id, 'umbrcom_label_override', sanitize_text_field( wp_unslash( $_POST['umbrcom_label_override'] ?? '' ) ) );
	}

	public static function register_rest_field() {
		register_rest_field( 'product_cat', 'umbrcom', array(
			'get_callback' => function ( $term_arr ) {
				$id = $term_arr['id'];
				return array(
					'tile_image'     => wp_get_attachment_url( get_term_meta( $id, 'umbrcom_tile_image', true ) ),
					'label_override' => get_term_meta( $id, 'umbrcom_label_override', true ),
				);
			},
			'schema' => null,
		) );
	}
}
