<?php
/**
 * REST CORS — the React app (its own domain / Vercel / localhost during
 * dev) needs permission to call this WordPress install's REST API from
 * the browser. Configure allowed production origins in wp-config.php:
 *
 *   define( 'UMBRCOM_CE_ALLOWED_ORIGINS', array(
 *       'https://umbrcom.co.il',
 *       'https://www.umbrcom.co.il',
 *       'https://ambercom.co.il',
 *   ) );
 *
 * Left undefined, any origin is allowed (dev-friendly default) — lock this
 * down before going live.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Rest_Cors {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'add_cors_support' ), 15 );
	}

	public static function add_cors_support() {
		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

		add_filter( 'rest_pre_serve_request', function ( $value ) {
			$origin  = get_http_origin();
			$allowed = defined( 'UMBRCOM_CE_ALLOWED_ORIGINS' ) ? UMBRCOM_CE_ALLOWED_ORIGINS : array();

			if ( empty( $allowed ) || ( $origin && in_array( $origin, $allowed, true ) ) ) {
				header( 'Access-Control-Allow-Origin: ' . ( $origin ? esc_url_raw( $origin ) : '*' ) );
				header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
				header( 'Access-Control-Allow-Credentials: true' );
				header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WC-Store-API-Nonce, Nonce' );
				header( 'Access-Control-Expose-Headers: X-WC-Store-API-Nonce, X-WC-Store-API-Nonce-Timestamp' );
			}

			return $value;
		} );
	}
}
