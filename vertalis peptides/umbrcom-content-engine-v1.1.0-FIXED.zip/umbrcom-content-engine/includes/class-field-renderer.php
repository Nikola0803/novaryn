<?php
/**
 * Umbrcom_Fields — a small, self-contained field-rendering toolkit used by
 * every meta box in this plugin (Page Builder, product fields, Series,
 * Site Settings, category fields). Everything here is built on core
 * WordPress admin APIs only:
 *
 *   - Images/files → wp.media (core JS, enqueued via wp_enqueue_media())
 *   - Colors       → wp-color-picker (core-bundled script/style)
 *   - Repeaters    → native <template> cloning (assets/admin.js), with
 *                    up/down buttons for reordering instead of a drag-drop
 *                    library, and one of three index placeholder tokens
 *                    (__L1_INDEX__ / __L2_INDEX__ / __L3_INDEX__) so nested
 *                    repeaters (e.g. footer columns → their links) never
 *                    collide when a template is cloned.
 *
 * No ACF, no third-party form builder — every field type here is ~10-30
 * lines of plain PHP + a matching bit of vanilla JS in admin.js.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_Fields {

	public static function text( $name, $value = '', $label = '', $placeholder = '', $class = '' ) {
		self::field_wrap_open( $label );
		printf(
			'<input type="text" name="%1$s" value="%2$s" placeholder="%3$s" class="widefat umbrcom-input %4$s" />',
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $placeholder ),
			esc_attr( $class )
		);
		self::field_wrap_close();
	}

	public static function url( $name, $value = '', $label = '' ) {
		self::field_wrap_open( $label );
		printf(
			'<input type="url" name="%1$s" value="%2$s" class="widefat umbrcom-input" placeholder="https://" />',
			esc_attr( $name ),
			esc_attr( $value )
		);
		self::field_wrap_close();
	}

	public static function number( $name, $value = '', $label = '', $min = null, $max = null ) {
		self::field_wrap_open( $label );
		printf(
			'<input type="number" name="%1$s" value="%2$s" %3$s %4$s class="umbrcom-input" />',
			esc_attr( $name ),
			esc_attr( $value ),
			$min !== null ? 'min="' . esc_attr( $min ) . '"' : '',
			$max !== null ? 'max="' . esc_attr( $max ) . '"' : ''
		);
		self::field_wrap_close();
	}

	public static function textarea( $name, $value = '', $label = '', $rows = 3 ) {
		self::field_wrap_open( $label );
		printf(
			'<textarea name="%1$s" rows="%2$d" class="widefat umbrcom-input">%3$s</textarea>',
			esc_attr( $name ),
			(int) $rows,
			esc_textarea( $value )
		);
		self::field_wrap_close();
	}

	/** Plain-HTML content field for the Page Builder's "Rich Text Block".
	 *  Not a full TinyMCE editor (that doesn't survive being cloned inside
	 *  a repeater reliably) — basic tags (p, b, i, a, ul/li, h3) are fine
	 *  and render as-is on the frontend. */
	public static function html_textarea( $name, $value = '', $label = '' ) {
		self::field_wrap_open( $label . ' (HTML — נתמכים: <p>, <b>, <i>, <a>, <ul>/<li>, <h3>)' );
		printf(
			'<textarea name="%1$s" rows="6" class="widefat umbrcom-input umbrcom-mono">%2$s</textarea>',
			esc_attr( $name ),
			esc_textarea( $value )
		);
		self::field_wrap_close();
	}

	public static function checkbox( $name, $checked = false, $label = '' ) {
		printf(
			'<label class="umbrcom-checkbox"><input type="hidden" name="%1$s" value="0" /><input type="checkbox" name="%1$s" value="1" %2$s /> %3$s</label>',
			esc_attr( $name ),
			checked( (bool) $checked, true, false ),
			esc_html( $label )
		);
	}

	public static function select( $name, $value, array $choices, $label = '' ) {
		self::field_wrap_open( $label );
		echo '<select name="' . esc_attr( $name ) . '" class="widefat umbrcom-input">';
		foreach ( $choices as $key => $choice_label ) {
			printf(
				'<option value="%1$s" %2$s>%3$s</option>',
				esc_attr( $key ),
				selected( $value, $key, false ),
				esc_html( $choice_label )
			);
		}
		echo '</select>';
		self::field_wrap_close();
	}

	public static function color( $name, $value = '', $label = '' ) {
		self::field_wrap_open( $label );
		printf(
			'<input type="text" name="%1$s" value="%2$s" class="umbrcom-color-field" data-default-color="%2$s" />',
			esc_attr( $name ),
			esc_attr( $value )
		);
		self::field_wrap_close();
	}

	/** Checkbox list — used for the Categories Grid's taxonomy multi-select.
	 *  $options is [ id => label ], $selected is an array of selected ids. */
	public static function checkbox_list( $name, array $selected, array $options, $label = '' ) {
		self::field_wrap_open( $label );
		echo '<div class="umbrcom-checkbox-list">';
		foreach ( $options as $id => $option_label ) {
			printf(
				'<label class="umbrcom-checkbox"><input type="checkbox" name="%1$s[]" value="%2$s" %3$s /> %4$s</label>',
				esc_attr( $name ),
				esc_attr( $id ),
				checked( in_array( (int) $id, array_map( 'intval', $selected ), true ), true, false ),
				esc_html( $option_label )
			);
		}
		echo '</div>';
		self::field_wrap_close();
	}

	/** Image picker — stores an attachment ID, shows a thumbnail preview. */
	public static function image( $name, $attachment_id = '', $label = '' ) {
		$url = $attachment_id ? wp_get_attachment_image_url( (int) $attachment_id, 'medium' ) : '';
		self::field_wrap_open( $label );
		?>
		<div class="umbrcom-media-field">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" class="umbrcom-media-value" />
			<div class="umbrcom-media-preview" <?php echo $url ? '' : 'style="display:none"'; ?>>
				<img src="<?php echo esc_url( $url ?: '' ); ?>" />
			</div>
			<button type="button" class="button umbrcom-media-choose"><?php echo $url ? 'החלפת תמונה' : 'בחירת תמונה'; ?></button>
			<button type="button" class="button umbrcom-media-remove" <?php echo $url ? '' : 'style="display:none"'; ?>>הסרה</button>
		</div>
		<?php
		self::field_wrap_close();
	}

	/** File picker (3D models, videos) — stores an attachment ID + shows the filename. */
	public static function file( $name, $attachment_id = '', $label = '', $mime_types = '' ) {
		$url      = $attachment_id ? wp_get_attachment_url( (int) $attachment_id ) : '';
		$filename = $url ? basename( $url ) : '';
		self::field_wrap_open( $label );
		?>
		<div class="umbrcom-media-field" data-mime-types="<?php echo esc_attr( $mime_types ); ?>">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" class="umbrcom-media-value" />
			<span class="umbrcom-media-filename"><?php echo esc_html( $filename ); ?></span>
			<button type="button" class="button umbrcom-media-choose-file"><?php echo $filename ? 'החלפת קובץ' : 'בחירת קובץ'; ?></button>
			<button type="button" class="button umbrcom-media-remove" <?php echo $filename ? '' : 'style="display:none"'; ?>>הסרה</button>
		</div>
		<?php
		self::field_wrap_close();
	}

	/**
	 * Relationship field — search-and-add pill picker for WordPress posts
	 * (used for "products", "articles", "related accessories"). Stores an
	 * array of post IDs. Search is powered by the umbrcom_search_posts
	 * AJAX action (see class-admin-assets.php).
	 */
	public static function relationship( $name, array $selected_ids, $post_type, $label = '' ) {
		self::field_wrap_open( $label );
		$items = array();
		foreach ( $selected_ids as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				$items[] = array( 'id' => $id, 'title' => get_the_title( $post ) );
			}
		}
		?>
		<div class="umbrcom-relationship" data-name="<?php echo esc_attr( $name ); ?>" data-post-type="<?php echo esc_attr( $post_type ); ?>">
			<div class="umbrcom-relationship-pills">
				<?php foreach ( $items as $item ) : ?>
					<span class="umbrcom-pill">
						<input type="hidden" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $item['id'] ); ?>" />
						<?php echo esc_html( $item['title'] ); ?>
						<button type="button" class="umbrcom-pill-remove">&times;</button>
					</span>
				<?php endforeach; ?>
			</div>
			<input type="text" class="widefat umbrcom-relationship-search" placeholder="חיפוש <?php echo esc_attr( $post_type === 'product' ? 'מוצרים' : ( $post_type === 'post' ? 'מאמרים' : $post_type ) ); ?>…" autocomplete="off" />
			<div class="umbrcom-relationship-results"></div>
		</div>
		<?php
		self::field_wrap_close();
	}

	/**
	 * Generic repeater: renders existing rows via $render_row callback,
	 * plus a hidden <template> (using $index_token in place of a real
	 * index) that admin.js clones when "+ Add" is clicked.
	 *
	 * @param string   $base_name    e.g. "umbrcom_spec_table" or "sections[3][perks]"
	 * @param array    $rows         existing row data
	 * @param callable $render_row   function( $base_name, $index_or_token, $row_data )
	 * @param string   $add_label
	 * @param string   $index_token  __L1_INDEX__ / __L2_INDEX__ / __L3_INDEX__
	 */
	public static function repeater( $base_name, array $rows, callable $render_row, $add_label, $index_token = '__L2_INDEX__' ) {
		?>
		<div class="umbrcom-repeater" data-name="<?php echo esc_attr( $base_name ); ?>" data-index-token="<?php echo esc_attr( $index_token ); ?>" data-next-index="<?php echo count( $rows ); ?>">
			<div class="umbrcom-repeater-rows">
				<?php foreach ( $rows as $i => $row ) : ?>
					<?php self::repeater_row_shell( $render_row, $base_name, $i, $row ); ?>
				<?php endforeach; ?>
			</div>
			<template class="umbrcom-row-template">
				<?php self::repeater_row_shell( $render_row, $base_name, $index_token, array() ); ?>
			</template>
			<button type="button" class="button umbrcom-add-row"><?php echo esc_html( $add_label ); ?></button>
		</div>
		<?php
	}

	private static function repeater_row_shell( callable $render_row, $base_name, $index, $row ) {
		?>
		<div class="umbrcom-row">
			<div class="umbrcom-row-body">
				<?php call_user_func( $render_row, $base_name, $index, $row ); ?>
			</div>
			<div class="umbrcom-row-controls">
				<button type="button" class="umbrcom-row-up" title="הזזה למעלה">&uarr;</button>
				<button type="button" class="umbrcom-row-down" title="הזזה למטה">&darr;</button>
				<button type="button" class="umbrcom-row-remove" title="הסרה">&times;</button>
			</div>
		</div>
		<?php
	}

	private static function field_wrap_open( $label ) {
		echo '<div class="umbrcom-field">';
		if ( $label ) {
			echo '<label class="umbrcom-field-label">' . esc_html( $label ) . '</label>';
		}
	}

	private static function field_wrap_close() {
		echo '</div>';
	}

	/**
	 * Recursively sanitizes a $_POST array of arbitrary depth (text fields
	 * only — repeaters, sections, nested rows). Numbers/checkboxes/URLs are
	 * re-validated at the point they're read back out by each meta box,
	 * this just guards against stored HTML/script injection in free-text
	 * fields.
	 */
	public static function sanitize_recursive( $value ) {
		if ( is_array( $value ) ) {
			return array_map( array( __CLASS__, 'sanitize_recursive' ), $value );
		}
		return sanitize_textarea_field( wp_unslash( $value ) );
	}
}
