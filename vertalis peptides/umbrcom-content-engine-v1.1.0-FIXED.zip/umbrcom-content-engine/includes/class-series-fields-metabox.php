<?php
/**
 * "Series Details" meta box on the Series CPT (Hydra, Dett, Sora…).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Series_Fields_Metabox {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_wf_series', array( __CLASS__, 'save' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_fields' ) );
	}

	public static function add_meta_box() {
		add_meta_box( 'umbrcom_series_fields', 'פרטי הסדרה', array( __CLASS__, 'render' ), 'wf_series', 'normal', 'high' );
	}

	public static function render( $post ) {
		wp_nonce_field( 'umbrcom_series_save', 'umbrcom_series_nonce' );
		echo '<div class="umbrcom-rtl">';

		$name_he     = get_post_meta( $post->ID, '_umbrcom_name_he', true );
		$tagline     = get_post_meta( $post->ID, '_umbrcom_tagline', true );
		$description = get_post_meta( $post->ID, '_umbrcom_description', true );
		$banner      = get_post_meta( $post->ID, '_umbrcom_banner_image', true );
		$color       = get_post_meta( $post->ID, '_umbrcom_accent_color', true ) ?: '#3ab4f2';
		$linked_cat  = get_post_meta( $post->ID, '_umbrcom_linked_category', true );
		$is_featured = get_post_meta( $post->ID, '_umbrcom_is_featured', true );

		Umbrcom_Fields::text( 'umbrcom_name_he', $name_he, 'שם בעברית' );
		Umbrcom_Fields::text( 'umbrcom_tagline', $tagline, 'סלוגן' );
		Umbrcom_Fields::textarea( 'umbrcom_description', $description, 'תיאור', 3 );
		Umbrcom_Fields::image( 'umbrcom_banner_image', $banner, 'תמונת באנר' );
		Umbrcom_Fields::color( 'umbrcom_accent_color', $color, 'צבע הדגשה' );

		$cat_choices = array( '' => '— בחירה —' );
		foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) ) as $term ) {
			$cat_choices[ $term->term_id ] = $term->name;
		}
		Umbrcom_Fields::select( 'umbrcom_linked_category', $linked_cat, $cat_choices, 'קטגוריית מוצרים מקושרת (ספירת "X מוצרים" נמשכת בזמן אמת מקטגוריה זו)' );
		Umbrcom_Fields::checkbox( 'umbrcom_is_featured', $is_featured === '1', 'הצגה כבאנר הראשי הגדול' );
		echo '</div>';
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['umbrcom_series_nonce'] ) || ! wp_verify_nonce( $_POST['umbrcom_series_nonce'], 'umbrcom_series_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_umbrcom_name_he', sanitize_text_field( wp_unslash( $_POST['umbrcom_name_he'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_tagline', sanitize_text_field( wp_unslash( $_POST['umbrcom_tagline'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_description', sanitize_textarea_field( wp_unslash( $_POST['umbrcom_description'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_banner_image', absint( $_POST['umbrcom_banner_image'] ?? 0 ) );
		update_post_meta( $post_id, '_umbrcom_accent_color', sanitize_hex_color( wp_unslash( $_POST['umbrcom_accent_color'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_linked_category', absint( $_POST['umbrcom_linked_category'] ?? 0 ) );
		update_post_meta( $post_id, '_umbrcom_is_featured', ! empty( $_POST['umbrcom_is_featured'] ) ? '1' : '0' );
	}

	public static function register_rest_fields() {
		register_rest_field( 'series', 'umbrcom', array(
			'get_callback' => function ( $post_arr ) {
				$id          = $post_arr['id'];
				$category_id = (int) get_post_meta( $id, '_umbrcom_linked_category', true );
				$count       = 0;
				if ( $category_id ) {
					$term  = get_term( $category_id, 'product_cat' );
					$count = ( $term && ! is_wp_error( $term ) ) ? $term->count : 0;
				}
				return array(
					'name_he'      => get_post_meta( $id, '_umbrcom_name_he', true ),
					'tagline'      => get_post_meta( $id, '_umbrcom_tagline', true ),
					'description'  => get_post_meta( $id, '_umbrcom_description', true ),
					'banner_image' => wp_get_attachment_url( get_post_meta( $id, '_umbrcom_banner_image', true ) ),
					'accent_color' => get_post_meta( $id, '_umbrcom_accent_color', true ),
					'is_featured'  => get_post_meta( $id, '_umbrcom_is_featured', true ) === '1',
					'products'     => $count,
				);
			},
			'schema' => null,
		) );
	}
}
