<?php
/**
 * Registers the "Series" content type (Hydra, Dett, Sora, etc.) so the
 * client can add/reorder/edit product series from wp-admin without touching
 * code. Fields (tagline, description, hero image, accent color, linked
 * WooCommerce category) are added by class-series-fields-metabox.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Series_CPT {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
	}

	public static function register_post_type() {
		register_post_type( 'wf_series', array(
			'label'                 => 'סדרות',
			'labels'                => array(
				'name'          => 'סדרות',
				'singular_name' => 'סדרה',
				'add_new_item'  => 'הוספת סדרה חדשה',
				'edit_item'     => 'עריכת סדרה',
				'menu_name'     => 'סדרות',
			),
			'public'                => true,
			'show_in_menu'          => true,
			'menu_icon'             => 'dashicons-controls-repeat',
			'menu_position'         => 21, // just under WooCommerce Products
			'supports'              => array( 'title', 'thumbnail', 'page-attributes' ),
			// page-attributes gives a "menu_order" field so the client can
			// order Series by typing an order number (or with a plugin like
			// "Simple Page Ordering" for drag-reorder in the list table).
			'has_archive'           => false,
			'rewrite'               => array( 'slug' => 'series' ),
			'show_in_rest'          => true,
			'rest_base'             => 'series',
			'rest_controller_class' => 'WP_REST_Posts_Controller',
		) );
	}
}
