<?php
/**
 * Pelecard payment gateway for the headless checkout.
 *
 * Flow (Pelecard "Iframe/Redirect V2" — PaymentGW):
 *
 *   1. React checkout POSTs the cart + customer details to
 *      POST /wp-json/umbrcom/v1/checkout
 *      → we build a real WooCommerce order server-side (prices come from
 *        WooCommerce, never from the client), call Pelecard `PaymentGW/init`
 *        and return the hosted payment page URL.
 *   2. The browser is sent to that URL (redirect or iframe). Pelecard shows
 *      its PCI-compliant card form — card numbers never touch our servers.
 *   3. On success Pelecard redirects the shopper to
 *      {frontend}/checkout/result?...PelecardTransactionId=&PelecardStatusCode=&ConfirmationKey=...
 *      AND (belt-and-braces) server-posts the same data to our
 *      ServerSideGoodURL notify endpoint.
 *   4. Both paths land in the same validation: StatusCode must be "000" and
 *      `PaymentGW/ValidateByUniqueKey` (ConfirmationKey + UserKey + amount
 *      in agorot) must return 1. Only then is the order marked paid.
 *
 * Credentials live in their own option (`umbrcom_pelecard`) — deliberately
 * NOT inside `umbrcom_settings`, which is exposed publicly via
 * /umbrcom/v1/settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Pelecard {

	const OPTION_KEY = 'umbrcom_pelecard';

	/** Must mirror SHIPPING_OPTIONS in src/pages/checkout/page.tsx. */
	const SHIPPING_METHODS = array(
		'standard' => array( 'label' => 'משלוח סטנדרטי', 'cost' => 28 ),
		'express'  => array( 'label' => 'משלוח מהיר',    'cost' => 49 ),
		'free'     => array( 'label' => 'משלוח חינם',    'cost' => 0, 'min_order' => 200 ),
	);

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/* ── Settings ─────────────────────────────────────────────────────── */

	public static function get_settings() {
		$defaults = array(
			'enabled'      => '0',
			'terminal'     => '',
			'user'         => '',
			'password'     => '',
			'gateway_base' => 'https://gateway21.pelecard.biz',
			'frontend_url' => 'https://umbrcom.co.il',
			'max_payments' => 1,
			'language'     => 'HE',
		);
		return wp_parse_args( get_option( self::OPTION_KEY, array() ), $defaults );
	}

	public static function add_menu() {
		add_submenu_page(
			'umbrcom-site-settings',
			'Pelecard',
			'Pelecard',
			'manage_options',
			'umbrcom-pelecard',
			array( __CLASS__, 'render_settings' )
		);
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['umbrcom_pelecard_nonce'] ) && wp_verify_nonce( $_POST['umbrcom_pelecard_nonce'], 'umbrcom_pelecard_save' ) ) {
			$raw = wp_unslash( $_POST['pelecard'] ?? array() );
			update_option( self::OPTION_KEY, array(
				'enabled'      => ! empty( $raw['enabled'] ) ? '1' : '0',
				'terminal'     => sanitize_text_field( $raw['terminal'] ?? '' ),
				'user'         => sanitize_text_field( $raw['user'] ?? '' ),
				'password'     => (string) ( $raw['password'] ?? '' ), // may contain symbols — don't mangle
				'gateway_base' => esc_url_raw( untrailingslashit( $raw['gateway_base'] ?? 'https://gateway21.pelecard.biz' ) ),
				'frontend_url' => esc_url_raw( untrailingslashit( $raw['frontend_url'] ?? '' ) ),
				'max_payments' => max( 1, absint( $raw['max_payments'] ?? 1 ) ),
				'language'     => in_array( $raw['language'] ?? 'HE', array( 'HE', 'EN', 'RU' ), true ) ? $raw['language'] : 'HE',
			), false );
			echo '<div class="notice notice-success"><p>הגדרות Pelecard נשמרו.</p></div>';
		}

		$s = self::get_settings();
		?>
		<div class="wrap umbrcom-settings-page umbrcom-rtl" dir="rtl">
			<h1>Pelecard — סליקת אשראי</h1>
			<p>את פרטי הגישה (מספר מסוף + משתמש/סיסמת API) מקבלים מהתמיכה של Pelecard. הם נשמרים באפשרות נפרדת ו<strong>לעולם</strong> אינם נחשפים בנקודת ההגדרות הציבורית.</p>
			<form method="post">
				<?php wp_nonce_field( 'umbrcom_pelecard_save', 'umbrcom_pelecard_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">הפעלה</th>
						<td><label><input type="checkbox" name="pelecard[enabled]" value="1" <?php checked( $s['enabled'], '1' ); ?> /> קבלת תשלומים דרך Pelecard</label></td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-terminal">מספר מסוף (Terminal)</label></th>
						<td><input id="plc-terminal" type="text" class="regular-text" name="pelecard[terminal]" value="<?php echo esc_attr( $s['terminal'] ); ?>" placeholder="0962210" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-user">משתמש API</label></th>
						<td><input id="plc-user" type="text" class="regular-text" name="pelecard[user]" value="<?php echo esc_attr( $s['user'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-pass">סיסמת API</label></th>
						<td><input id="plc-pass" type="password" class="regular-text" name="pelecard[password]" value="<?php echo esc_attr( $s['password'] ); ?>" autocomplete="new-password" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-base">כתובת שער הסליקה</label></th>
						<td>
							<input id="plc-base" type="url" class="regular-text" name="pelecard[gateway_base]" value="<?php echo esc_attr( $s['gateway_base'] ); ?>" />
							<p class="description">בדרך כלל <code>https://gateway21.pelecard.biz</code> (או gateway20 — בהתאם לחשבון שלכם ב־Pelecard).</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-front">כתובת אתר החנות (Frontend)</label></th>
						<td>
							<input id="plc-front" type="url" class="regular-text" name="pelecard[frontend_url]" value="<?php echo esc_attr( $s['frontend_url'] ); ?>" />
							<p class="description">הכתובת בה רץ אתר ה־React — הלקוח מופנה אל <code dir="ltr">{Frontend URL}/checkout/result</code> לאחר התשלום.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-payments">מקסימום תשלומים</label></th>
						<td><input id="plc-payments" type="number" min="1" max="36" name="pelecard[max_payments]" value="<?php echo esc_attr( $s['max_payments'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="plc-lang">שפת עמוד התשלום</label></th>
						<td>
							<select id="plc-lang" name="pelecard[language]">
								<?php foreach ( array( 'HE', 'EN', 'RU' ) as $lang ) : ?>
									<option value="<?php echo esc_attr( $lang ); ?>" <?php selected( $s['language'], $lang ); ?>><?php echo esc_html( $lang ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
				<?php submit_button( 'שמירת הגדרות Pelecard' ); ?>
			</form>
		</div>
		<?php
	}

	/* ── REST routes ──────────────────────────────────────────────────── */

	public static function register_routes() {
		register_rest_route( 'umbrcom/v1', '/checkout', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'create_checkout' ),
			'permission_callback' => '__return_true',
		) );

		// Browser return leg — the React result page posts Pelecard's
		// redirect params here for validation.
		register_rest_route( 'umbrcom/v1', '/pelecard/confirm', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'confirm_payment' ),
			'permission_callback' => '__return_true',
		) );

		// Server-to-server leg (ServerSideGoodURL) — same validation, so the
		// order gets paid even if the shopper closes the tab mid-redirect.
		register_rest_route( 'umbrcom/v1', '/pelecard/notify', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'notify' ),
			'permission_callback' => '__return_true',
		) );

		// Lets the result page show order status (paid / pending / failed).
		register_rest_route( 'umbrcom/v1', '/pelecard/status', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'order_status' ),
			'permission_callback' => '__return_true',
			'args'                => array(
				'order_id'  => array( 'required' => true ),
				'order_key' => array( 'required' => true ),
			),
		) );
	}

	/** Payments tiers proven in production on the Mashiach terminal —
	 *  capped by the Max Payments admin setting. */
	private static function max_payments_for( $amount, $cap ) {
		$tier = 1;
		if ( $amount >= 2500 ) { $tier = 12; }
		elseif ( $amount >= 1500 ) { $tier = 9; }
		elseif ( $amount >= 150 ) { $tier = 6; }
		return (string) min( $tier, max( 1, (int) $cap ) );
	}

	/* ── 1. Create order + Pelecard init ──────────────────────────────── */

	public static function create_checkout( \WP_REST_Request $req ) {
		$s = self::get_settings();
		if ( $s['enabled'] !== '1' || ! $s['terminal'] || ! $s['user'] || ! $s['password'] ) {
			return new \WP_Error( 'pelecard_disabled', 'התשלום אינו זמין כרגע. נסו שוב מאוחר יותר.', array( 'status' => 503 ) );
		}
		if ( ! function_exists( 'wc_create_order' ) ) {
			return new \WP_Error( 'no_woocommerce', 'WooCommerce is not active.', array( 'status' => 500 ) );
		}

		$body     = $req->get_json_params();
		$items    = is_array( $body['items'] ?? null ) ? $body['items'] : array();
		$customer = is_array( $body['customer'] ?? null ) ? $body['customer'] : array();
		$method   = sanitize_key( $body['shipping_method'] ?? 'standard' );

		if ( empty( $items ) ) {
			return new \WP_Error( 'empty_cart', 'הסל ריק.', array( 'status' => 400 ) );
		}
		if ( empty( $customer['email'] ) || ! is_email( $customer['email'] ) ) {
			return new \WP_Error( 'bad_email', 'כתובת אימייל לא תקינה.', array( 'status' => 400 ) );
		}

		// ── Build the order from live WooCommerce data ──
		$order = wc_create_order();
		$subtotal = 0;

		foreach ( $items as $line ) {
			$product = wc_get_product( absint( $line['id'] ?? 0 ) );
			$qty     = max( 1, absint( $line['quantity'] ?? 1 ) );
			if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
				$order->delete( true );
				return new \WP_Error( 'bad_item', 'אחד המוצרים בסל אינו זמין יותר.', array( 'status' => 400 ) );
			}
			$order->add_product( $product, $qty );
			$subtotal += (float) $product->get_price() * $qty;
		}

		// ── Shipping (mirrors the frontend options exactly) ──
		$ship = self::SHIPPING_METHODS[ $method ] ?? self::SHIPPING_METHODS['standard'];
		$cost = $ship['cost'];
		if ( $method === 'free' && $subtotal < ( $ship['min_order'] ?? 0 ) ) {
			$ship = self::SHIPPING_METHODS['standard'];
			$cost = $ship['cost'];
		}
		$shipping_item = new \WC_Order_Item_Shipping();
		$shipping_item->set_method_title( $ship['label'] );
		$shipping_item->set_total( $cost );
		$order->add_item( $shipping_item );

		// ── Addresses ──
		$address = array(
			'first_name' => sanitize_text_field( $customer['first_name'] ?? '' ),
			'last_name'  => sanitize_text_field( $customer['last_name'] ?? '' ),
			'email'      => sanitize_email( $customer['email'] ),
			'phone'      => sanitize_text_field( $customer['phone'] ?? '' ),
			'address_1'  => sanitize_text_field( $customer['address'] ?? '' ),
			'city'       => sanitize_text_field( $customer['city'] ?? '' ),
			'postcode'   => sanitize_text_field( $customer['zip'] ?? '' ),
			'country'    => 'IL',
		);
		$order->set_address( $address, 'billing' );
		$order->set_address( $address, 'shipping' );
		if ( ! empty( $customer['notes'] ) ) {
			$order->set_customer_note( sanitize_textarea_field( $customer['notes'] ) );
		}
		$order->set_payment_method( 'pelecard' );
		$order->set_payment_method_title( 'Pelecard — כרטיס אשראי' );
		$order->set_status( 'pending' );
		$order->calculate_totals();
		$order->save();

		$order_id  = $order->get_id();
		$order_key = $order->get_order_key();
		$agorot    = (string) (int) round( (float) $order->get_total() * 100 );

		// ── Pelecard init ──
		$front     = untrailingslashit( $s['frontend_url'] );
		$result_qs = 'order_id=' . $order_id . '&order_key=' . rawurlencode( $order_key );
		// Field names below match the integration proven in production on the
		// Mashiach terminal (ServerSide*FeedbackURL — NOT ServerSideGoodURL).
		// Feedback is GET because this frontend is a static SPA and can't
		// receive a POSTed browser return.
		$payload   = array(
			'terminal'                   => $s['terminal'],
			'user'                       => $s['user'],
			'password'                   => $s['password'],
			'ActionType'                 => 'J4', // immediate charge
			'Currency'                   => 1,    // NIS
			'Total'                      => (int) $agorot,
			'FreeTotal'                  => false,
			'GoodURL'                    => $front . '/checkout/result?' . $result_qs,
			'ErrorURL'                   => $front . '/checkout/result?' . $result_qs . '&failed=1',
			'CancelURL'                  => $front . '/checkout',
			'FeedbackDataTransferMethod' => 'GET',
			'FeedbackOnTop'              => false,
			'ServerSideGoodFeedbackURL'  => set_url_scheme( rest_url( 'umbrcom/v1/pelecard/notify?order=' . $order_id . '&key=' . rawurlencode( $order_key ) ), 'https' ),
			'ServerSideErrorFeedbackURL' => set_url_scheme( rest_url( 'umbrcom/v1/pelecard/notify?status=error&order=' . $order_id ), 'https' ),
			'ParamX'                     => (string) $order_id,
			'UserKey'                    => $order_key,
			'MinPayments'                => 1,
			'MaxPayments'                => self::max_payments_for( (float) $order->get_total(), $s['max_payments'] ),
			'Language'                   => $s['language'],
			'TopText'                    => get_bloginfo( 'name' ),
			'EmailField'                 => $address['email'],
			'HiddenPelecardLogo'         => false,
			'CreateToken'                => false,
		);

		$resp = wp_remote_post( $s['gateway_base'] . '/PaymentGW/init', array(
			'timeout' => 25,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $payload ),
		) );

		if ( is_wp_error( $resp ) ) {
			$order->add_order_note( 'Pelecard init failed: ' . $resp->get_error_message() );
			return new \WP_Error( 'gateway_error', 'שגיאה בחיבור לספק הסליקה. נסו שוב.', array( 'status' => 502 ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $resp ), true );
		$url  = $data['URL'] ?? '';
		if ( ! $url ) {
			$err = $data['Error']['ErrMsg'] ?? wp_remote_retrieve_body( $resp );
			$order->add_order_note( 'Pelecard init rejected: ' . $err );
			return new \WP_Error( 'gateway_rejected', 'ספק הסליקה דחה את הבקשה. נסו שוב או פנו אלינו.', array( 'status' => 502 ) );
		}

		// ConfirmationKey arrives at init time on some Pelecard configs; if
		// present, keep it — validation can then cross-check both sources.
		if ( ! empty( $data['ConfirmationKey'] ) ) {
			$order->update_meta_data( '_pelecard_confirmation_key', sanitize_text_field( $data['ConfirmationKey'] ) );
		}
		$order->add_order_note( 'Pelecard payment page created. Awaiting payment.' );
		$order->save();

		return new \WP_REST_Response( array(
			'order_id'     => $order_id,
			'order_key'    => $order_key,
			'redirect_url' => esc_url_raw( $url ),
			'total'        => (float) $order->get_total(),
		), 200 );
	}

	/* ── 2. Validation (shared by browser leg, server leg, and status) ─── */

	/**
	 * Verifies payment and completes the order. Verification is attempted in
	 * two independent ways, either of which is sufficient:
	 *
	 *   a. ValidateByUniqueKey — when the browser return carried a
	 *      ConfirmationKey (anti-forgery check of key + order key + amount).
	 *   b. GetTransaction PULL — we fetch the transaction from Pelecard
	 *      ourselves and match it by ParamX = order ID. This is the
	 *      production-proven path from the Mashiach integration: Cloudflare
	 *      there silently blocked Pelecard's inbound server POST, so the
	 *      integration never depends on callbacks arriving at all.
	 *
	 * All meta is saved to the DB BEFORE payment_complete() fires, so any
	 * hooks listening on it (invoicing / ERP sync) see complete payment data.
	 */
	private static function validate_and_complete( $order_id, $order_key, $status_code = '', $transaction_id = '', $confirmation_key = '', $token = '' ) {
		$order = wc_get_order( absint( $order_id ) );
		if ( ! $order || ! hash_equals( $order->get_order_key(), (string) $order_key ) ) {
			return new \WP_Error( 'bad_order', 'הזמנה לא נמצאה.', array( 'status' => 404 ) );
		}

		// Idempotent — the notify leg, the browser leg, and status polls all land here.
		if ( $order->is_paid() ) {
			return array( 'status' => 'paid', 'order' => $order );
		}

		// Explicit decline from the redirect params — mark failed and stop.
		if ( $status_code !== '' && (string) $status_code !== '000' ) {
			$order->update_status( 'failed', 'Pelecard declined — status code ' . sanitize_text_field( $status_code ) );
			return array( 'status' => 'failed', 'order' => $order );
		}

		$s      = self::get_settings();
		$agorot = (int) round( (float) $order->get_total() * 100 );

		// ── a. ValidateByUniqueKey (when we have a ConfirmationKey) ──
		if ( $confirmation_key ) {
			$resp  = wp_remote_post( $s['gateway_base'] . '/PaymentGW/ValidateByUniqueKey', array(
				'timeout' => 25,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( array(
					'ConfirmationKey' => (string) $confirmation_key,
					'UniqueKey'       => (string) $order->get_order_key(),
					'TotalX100'       => (string) $agorot,
				) ),
			) );
			if ( ! is_wp_error( $resp ) && trim( wp_remote_retrieve_body( $resp ) ) === '1' ) {
				return self::complete_order( $order, array(
					'TransactionId' => $transaction_id,
					'Token'         => $token,
				), 'ValidateByUniqueKey' );
			}
		}

		// ── b. GetTransaction pull — fetch the transaction ourselves ──
		$txn = self::pull_transaction( $order_id, $s );
		if ( $txn ) {
			$shva = (string) ( $txn['ShvaResult'] ?? '' );
			if ( $shva !== '' && $shva !== '000' ) {
				$order->update_status( 'failed', 'Pelecard GetTransaction — ShvaResult ' . sanitize_text_field( $shva ) );
				return array( 'status' => 'failed', 'order' => $order );
			}
			// Amount sanity check when Pelecard reports it.
			$debit = (int) ( $txn['DebitTotal'] ?? 0 );
			if ( $debit > 0 && $debit !== $agorot ) {
				$order->add_order_note( sprintf( 'Pelecard amount mismatch — charged %d agorot, order total %d agorot. Left unpaid for manual review.', $debit, $agorot ) );
				return array( 'status' => 'invalid', 'order' => $order );
			}
			return self::complete_order( $order, $txn, 'GetTransaction' );
		}

		// Nothing verifiable yet (e.g. shopper refreshed before Pelecard
		// settled the transaction) — stay pending; the result page /
		// status endpoint will retry.
		return array( 'status' => 'pending', 'order' => $order );
	}

	/** Fetches this order's transaction from Pelecard (server-to-server, so
	 *  it works even when inbound callbacks are blocked by Cloudflare/WAF). */
	private static function pull_transaction( $order_id, $s ) {
		$resp = wp_remote_post( $s['gateway_base'] . '/PaymentGW/GetTransaction', array(
			'timeout' => 25,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( array(
				'terminal' => $s['terminal'],
				'user'     => $s['user'],
				'password' => $s['password'],
				'ecrfId'   => (string) $order_id,
			) ),
		) );
		if ( is_wp_error( $resp ) ) {
			return null;
		}
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );
		if ( empty( $data ) || ! is_array( $data ) ) {
			return null;
		}
		// Response can be a list — match on ParamX / AdditionalDetailsParamX.
		foreach ( $data as $t ) {
			if ( is_array( $t ) && (
				(int) ( $t['AdditionalDetailsParamX'] ?? -1 ) === (int) $order_id ||
				(int) ( $t['ParamX'] ?? -1 ) === (int) $order_id
			) ) {
				return ! empty( $t['TransactionId'] ) ? $t : null;
			}
		}
		// …or a single object.
		if ( ! empty( $data['TransactionId'] ) ) {
			return $data;
		}
		return null;
	}

	/** Writes all payment meta, SAVES, then completes — in that order. */
	private static function complete_order( $order, array $txn, $source ) {
		$transaction_id = sanitize_text_field( $txn['TransactionId'] ?? '' );

		$order->update_meta_data( '_pelecard_transaction_id', $transaction_id );
		if ( ! empty( $txn['Token'] ) ) {
			$order->update_meta_data( '_pelecard_token', sanitize_text_field( $txn['Token'] ) );
		}
		if ( ! empty( $txn['DebitApproveNumber'] ) ) {
			$order->update_meta_data( '_pelecard_approval_number', sanitize_text_field( $txn['DebitApproveNumber'] ) );
		}
		if ( ! empty( $txn['CreditCardNumber'] ) ) {
			$order->update_meta_data( '_pelecard_card_number', sanitize_text_field( $txn['CreditCardNumber'] ) );
		}
		if ( ! empty( $txn['CardHebrewName'] ) ) {
			$order->update_meta_data( '_pelecard_card_type_he', sanitize_text_field( $txn['CardHebrewName'] ) );
		}
		if ( ! empty( $txn['TotalPayments'] ) ) {
			$order->update_meta_data( '_pelecard_total_payments', sanitize_text_field( $txn['TotalPayments'] ) );
		}
		if ( ! empty( $txn['VoucherId'] ) ) {
			$order->update_meta_data( '_pelecard_voucher_id', sanitize_text_field( $txn['VoucherId'] ) );
		}
		$order->update_meta_data( '_pelecard_verified_via', $source );

		// Save BEFORE payment_complete so hooks reading meta from the DB
		// (invoicing / ERP sync) see complete payment data when they fire.
		$order->save();

		$order->payment_complete( $transaction_id );
		$order->add_order_note( 'Pelecard payment verified via ' . $source . ( $transaction_id ? ' (transaction ' . $transaction_id . ')' : '' ) . '.' );
		$order->save();

		return array( 'status' => 'paid', 'order' => $order );
	}

	public static function confirm_payment( \WP_REST_Request $req ) {
		$b = $req->get_json_params();
		$result = self::validate_and_complete(
			$b['order_id'] ?? 0,
			$b['order_key'] ?? '',
			(string) ( $b['status_code'] ?? '' ),
			(string) ( $b['transaction_id'] ?? '' ),
			(string) ( $b['confirmation_key'] ?? '' ),
			(string) ( $b['token'] ?? '' )
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new \WP_REST_Response( self::order_summary( $result['order'], $result['status'] ), 200 );
	}

	public static function notify( \WP_REST_Request $req ) {
		// Pelecard's server feedback can arrive as JSON (flat or under
		// ResultData), as a form POST, or as GET query params — and its key
		// names differ from the browser redirect's. Merge everything.
		$parsed = json_decode( $req->get_body(), true );
		if ( is_array( $parsed ) && isset( $parsed['ResultData'] ) && is_array( $parsed['ResultData'] ) ) {
			$all = array_merge( $parsed['ResultData'], $req->get_query_params() );
		} elseif ( is_array( $parsed ) ) {
			$all = array_merge( $parsed, $req->get_query_params() );
		} else {
			$all = array_merge( $req->get_body_params() ?: array(), $req->get_query_params() );
		}

		$order_id  = absint( $all['order'] ?? ( $all['ParamX'] ?? ( $all['AdditionalDetailsParamX'] ?? 0 ) ) );
		$order_key = (string) ( $all['key'] ?? ( $all['UserKey'] ?? '' ) );

		// Locate the order by whichever identifier arrived.
		if ( ! $order_key && $order_id ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$order_key = $order->get_order_key(); // notify leg is trusted via GetTransaction pull anyway
			}
		}

		$result = self::validate_and_complete(
			$order_id,
			$order_key,
			(string) ( $all['ShvaResult'] ?? ( $all['StatusCode'] ?? ( $all['PelecardStatusCode'] ?? '' ) ) ),
			(string) ( $all['TransactionId'] ?? ( $all['PelecardTransactionId'] ?? '' ) ),
			(string) ( $all['ConfirmationKey'] ?? '' ),
			(string) ( $all['Token'] ?? '' )
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new \WP_REST_Response( array( 'ok' => true, 'status' => $result['status'] ), 200 );
	}

	public static function order_status( \WP_REST_Request $req ) {
		$order = wc_get_order( absint( $req->get_param( 'order_id' ) ) );
		if ( ! $order || ! hash_equals( $order->get_order_key(), (string) $req->get_param( 'order_key' ) ) ) {
			return new \WP_Error( 'bad_order', 'הזמנה לא נמצאה.', array( 'status' => 404 ) );
		}

		// Self-healing: while pending, each status check re-attempts the
		// GetTransaction pull — a refresh of the result page settles the
		// order even if every callback was lost.
		if ( ! $order->is_paid() && ! $order->has_status( 'failed' ) ) {
			$result = self::validate_and_complete( $order->get_id(), $order->get_order_key() );
			if ( ! is_wp_error( $result ) ) {
				return new \WP_REST_Response( self::order_summary( $result['order'], $result['status'] ), 200 );
			}
		}

		$status = $order->is_paid() ? 'paid' : ( $order->has_status( 'failed' ) ? 'failed' : 'pending' );
		return new \WP_REST_Response( self::order_summary( $order, $status ), 200 );
	}

	private static function order_summary( $order, $status ) {
		return array(
			'status'       => $status,
			'order_id'     => $order->get_id(),
			'order_number' => $order->get_order_number(),
			'total'        => (float) $order->get_total(),
			'email'        => $order->get_billing_email(),
			'first_name'   => $order->get_billing_first_name(),
		);
	}
}
