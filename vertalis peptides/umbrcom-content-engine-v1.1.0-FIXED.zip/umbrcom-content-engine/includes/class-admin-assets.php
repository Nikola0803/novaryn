<?php
/**
 * Enqueues the plugin's admin CSS/JS (repeaters, media pickers, color
 * pickers, section reordering) and the small AJAX action that powers the
 * relationship field's search-and-add pill picker.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Admin_Assets {

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_umbrcom_search_posts', array( __CLASS__, 'ajax_search_posts' ) );
	}

	public static function enqueue( $hook ) {
		global $post_type;

		$screens_with_fields = array( 'page', 'product', 'wf_series' );
		$is_field_screen     = in_array( $hook, array( 'post.php', 'post-new.php' ), true ) && in_array( $post_type, $screens_with_fields, true );
		$is_settings_screen  = isset( $_GET['page'] ) && in_array( $_GET['page'], array( 'umbrcom-site-settings', 'umbrcom-pelecard' ), true ); // phpcs:ignore
		$is_term_screen      = in_array( $hook, array( 'term.php', 'edit-tags.php' ), true );

		if ( ! $is_field_screen && ! $is_settings_screen && ! $is_term_screen ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		wp_enqueue_style( 'umbrcom-ce-admin', UMBRCOM_CE_URL . 'assets/admin.css', array(), UMBRCOM_CE_VERSION );
		wp_enqueue_script(
			'umbrcom-ce-admin',
			UMBRCOM_CE_URL . 'assets/admin.js',
			array( 'jquery', 'wp-color-picker' ),
			UMBRCOM_CE_VERSION,
			true
		);
		wp_localize_script( 'umbrcom-ce-admin', 'UmbrcomCE', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'umbrcom_ce_admin' ),
		) );
	}

	/** Powers the relationship field's live search (products / posts). */
	public static function ajax_search_posts() {
		check_ajax_referer( 'umbrcom_ce_admin', 'nonce' );

		$search    = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
		$post_type = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : 'post';

		$query = new WP_Query( array(
			'post_type'      => $post_type,
			's'              => $search,
			'posts_per_page' => 15,
			'post_status'    => 'publish',
		) );

		$results = array();
		foreach ( $query->posts as $p ) {
			$results[] = array( 'id' => $p->ID, 'title' => get_the_title( $p ) );
		}

		wp_send_json( $results );
	}
}
