<?php
/**
 * Extends the public WooCommerce Store API (`/wp-json/wc/store/v1/products`)
 * with an "umbrcom" data block per product (spec table, 3D model, badges,
 * accessories) — so the frontend gets everything in the same request it
 * uses to list/fetch a product. No auth, no WooCommerce REST API keys.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Product_Fields {

	public static function init() {
		add_action( 'woocommerce_blocks_loaded', array( __CLASS__, 'register_store_api_field' ) );
	}

	public static function register_store_api_field() {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}

		woocommerce_store_api_register_endpoint_data( array(
			'endpoint'        => \Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema::IDENTIFIER,
			'namespace'       => 'umbrcom',
			'data_callback'   => array( __CLASS__, 'product_extra_data' ),
			'schema_callback' => array( __CLASS__, 'product_extra_schema' ),
			'schema_type'     => ARRAY_A,
		) );
	}

	public static function product_extra_data( $product ) {
		$id = $product->get_id();

		$accessory_ids = get_post_meta( $id, '_umbrcom_related_accessories', true );
		if ( empty( $accessory_ids ) ) {
			$accessory_ids = wc_get_related_products( $id, 4 );
		}

		return array(
			'brand_label'            => (string) get_post_meta( $id, '_umbrcom_brand_label', true ) ?: 'Waterfall',
			'feature_cards'          => get_post_meta( $id, '_umbrcom_feature_cards', true ) ?: array(),
			'short_description'      => (string) get_post_meta( $id, '_umbrcom_short_description', true ),
			'description_paragraphs' => get_post_meta( $id, '_umbrcom_description_paragraphs', true ) ?: array(),
			'features'               => get_post_meta( $id, '_umbrcom_features', true ) ?: array(),
			'spec_table'             => get_post_meta( $id, '_umbrcom_spec_table', true ) ?: array(),
			'shipping_info'          => get_post_meta( $id, '_umbrcom_shipping_info', true ) ?: array(),
			'youtube_url'            => (string) get_post_meta( $id, '_umbrcom_youtube_url', true ),
			'ai_review'              => (string) get_post_meta( $id, '_umbrcom_ai_review', true ),
			'tech_specs_html'        => (string) get_post_meta( $id, '_umbrcom_tech_specs_html', true ),
			'package_contents'       => self::package_contents_string( $id ),
			'warranty'               => (string) get_post_meta( $id, '_umbrcom_warranty', true ),
			'model_3d_url'           => (string) wp_get_attachment_url( get_post_meta( $id, '_umbrcom_model_3d_url', true ) ),
			'model_usdz_url'         => (string) wp_get_attachment_url( get_post_meta( $id, '_umbrcom_model_usdz_url', true ) ),
			'ar_enabled'             => get_post_meta( $id, '_umbrcom_ar_enabled', true ) === '1',
			'badge_text_override'    => (string) get_post_meta( $id, '_umbrcom_badge_text', true ),
			'is_new'                 => get_post_meta( $id, '_umbrcom_is_new', true ) === '1',
			'related_accessory_ids'  => array_map( 'absint', (array) $accessory_ids ),
		);
	}

	/** package_contents was briefly stored as a repeater array — normalize
	 *  either format to a plain "one item per line" string. */
	private static function package_contents_string( $id ) {
		$val = get_post_meta( $id, '_umbrcom_package_contents', true );
		if ( is_array( $val ) ) {
			return implode( "\n", array_filter( wp_list_pluck( $val, 'text' ) ) );
		}
		return (string) $val;
	}

	public static function product_extra_schema() {
		$string_arr = array( 'type' => 'array', 'context' => array( 'view', 'edit' ), 'readonly' => true );
		return array(
			'brand_label'            => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'feature_cards'          => $string_arr,
			'short_description'      => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'description_paragraphs' => $string_arr,
			'features'               => $string_arr,
			'spec_table'             => $string_arr,
			'shipping_info'          => $string_arr,
			'youtube_url'            => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'ai_review'              => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'tech_specs_html'        => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'package_contents'       => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'warranty'               => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'model_3d_url'           => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'model_usdz_url'         => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'ar_enabled'             => array( 'type' => 'boolean', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'badge_text_override'    => array( 'type' => 'string', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'is_new'                 => array( 'type' => 'boolean', 'context' => array( 'view', 'edit' ), 'readonly' => true ),
			'related_accessory_ids'  => $string_arr,
		);
	}
}
