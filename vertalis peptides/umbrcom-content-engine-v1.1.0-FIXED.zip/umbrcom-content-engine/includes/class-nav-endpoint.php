<?php
/**
 * GET /wp-json/umbrcom/v1/nav — live WooCommerce categories (with their
 * tile image / label override) plus the Series list, for the header's
 * "כל הקטגוריות" dropdown and the homepage Categories Grid.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Nav_Endpoint {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route( 'umbrcom/v1', '/nav', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_nav' ),
			'permission_callback' => '__return_true',
		) );
	}

	public static function get_nav() {
		$terms = get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'orderby'    => 'menu_order',
			'order'      => 'ASC',
		) );

		$categories = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( $term->slug === 'uncategorized' ) {
					continue;
				}
				$label_override = get_term_meta( $term->term_id, 'umbrcom_label_override', true );
				$tile_image_id  = get_term_meta( $term->term_id, 'umbrcom_tile_image', true );

				$categories[] = array(
					'id'    => $term->term_id,
					'label' => $label_override ?: $term->name,
					'slug'  => $term->slug,
					'link'  => '/shop/' . $term->slug,
					'image' => $tile_image_id ? wp_get_attachment_url( $tile_image_id ) : wc_placeholder_img_src( 'full' ),
					'count' => $term->count,
				);
			}
		}

		$series_posts = get_posts( array(
			'post_type'      => 'wf_series',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		) );

		$series = array();
		foreach ( $series_posts as $post ) {
			$category_id = (int) get_post_meta( $post->ID, '_umbrcom_linked_category', true );
			$count       = 0;
			if ( $category_id ) {
				$term  = get_term( $category_id, 'product_cat' );
				$count = ( $term && ! is_wp_error( $term ) ) ? $term->count : 0;
			}

			$series[] = array(
				'id'          => $post->ID,
				'name'        => $post->post_title,
				'name_he'     => get_post_meta( $post->ID, '_umbrcom_name_he', true ),
				'tagline'     => get_post_meta( $post->ID, '_umbrcom_tagline', true ),
				'description' => get_post_meta( $post->ID, '_umbrcom_description', true ),
				'image'       => wp_get_attachment_url( get_post_meta( $post->ID, '_umbrcom_banner_image', true ) ),
				'color'       => get_post_meta( $post->ID, '_umbrcom_accent_color', true ),
				'path'        => '/series/' . $post->post_name,
				'is_featured' => get_post_meta( $post->ID, '_umbrcom_is_featured', true ) === '1',
				'products'    => $count,
			);
		}

		return new \WP_REST_Response( array(
			'categories' => $categories,
			'series'     => $series,
		), 200 );
	}
}
