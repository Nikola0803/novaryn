<?php
/**
 * Auto-generates a WordPress Page (with Page Builder sections already
 * filled in, matching what's live on the site today) for every content
 * route the React app has — so activating this plugin gives you a fully
 * populated, editable site immediately, not an empty shell you have to
 * build from scratch.
 *
 * Runs once on activation, and is re-runnable any time from the "Sync
 * Pages Now" button on the Site Settings screen (safe to run repeatedly —
 * it only ever creates pages that don't already exist; it never
 * overwrites a page you've since edited).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Page_Sync {

	public static function init() {
		add_action( 'admin_post_umbrcom_sync_pages', array( __CLASS__, 'handle_manual_sync' ) );
	}

	public static function handle_manual_sync() {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'umbrcom_sync_pages' ) ) {
			wp_die( 'Not allowed.' );
		}
		$created = self::sync();
		wp_safe_redirect( add_query_arg( array( 'page' => 'umbrcom-site-settings', 'synced' => count( $created ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Creates any missing pages from the manifest. Returns the slugs it
	 * actually created (existing pages are left completely untouched).
	 */
	public static function sync() {
		$created = array();
		foreach ( self::manifest() as $slug => $page ) {
			$existing = get_page_by_path( $slug, OBJECT, 'page' );
			if ( $existing ) {
				continue; // never touch a page that already exists
			}

			$post_id = wp_insert_post( array(
				'post_type'   => 'page',
				'post_title'  => $page['title'],
				'post_name'   => $slug,
				'post_status' => 'publish',
			) );

			if ( $post_id && ! is_wp_error( $post_id ) ) {
				update_post_meta( $post_id, Umbrcom_CE_Page_Builder_Metabox::META_KEY, $page['sections'] );
				$created[] = $slug;
			}
		}
		return $created;
	}

	/**
	 * The full list of pages the React app expects, each pre-filled with
	 * Page Builder sections matching today's live content — so the client
	 * opens wp-admin and sees a real, editable version of the actual site,
	 * not a blank page.
	 */
	private static function manifest() {
		return array(

			'home' => array(
				'title'    => 'Home',
				'sections' => array(
					array(
						'type' => 'hero_video',
						'eyebrow' => 'Waterfall Collection 2025',
						'heading' => 'עיצוב שמרגישים.',
						'heading_emphasis' => 'איכות שנשארת.',
						'subheading' => "ברזי מטבח ואמבטיה פרמיום מאוסף Waterfall.\nעיצוב אירופאי, חומרים מושלמים, מחירים שמפתיעים לטובה.",
						'video' => 0, 'poster_image' => 0,
						'button_1_label' => 'אודות אמברקום', 'button_1_link' => '/about',
						'button_2_label' => 'לחנות שלנו', 'button_2_link' => '/shop',
					),
					array(
						'type' => 'trust_strip',
						'perks' => array(
							array( 'icon' => 'ri-shield-check-line', 'title' => 'אחריות מקיפה', 'subtitle' => 'אחריות מלאה ושירות מקצועי המעניקים שקט נפשי לאורך שנים' ),
							array( 'icon' => 'ri-medal-line', 'title' => 'חומרים איכותיים', 'subtitle' => 'ייצור מחומרים איכותיים עמידים לשמירה על מראה וביצועים לאורך זמן' ),
							array( 'icon' => 'ri-water-flash-line', 'title' => 'טכנולוגיית חיסכון במים', 'subtitle' => 'מערכות מתקדמות המסייעות לצמצם את צריכת המים ללא פגיעה בנוחות השימוש' ),
							array( 'icon' => 'ri-palette-line', 'title' => 'מגוון גימורים יוקרתיים', 'subtitle' => 'ניקל מוברש, שחור מט, זהב מוברש, רוז גולד וגימורים נוספים' ),
							array( 'icon' => 'ri-customer-service-2-line', 'title' => 'שירות ותמיכה בישראל', 'subtitle' => 'זמינות מלאה, מענה מקצועי ואספקת חלקי חילוף ושירות מקומי ללקוחות' ),
						),
					),
					array( 'type' => 'categories_grid', 'eyebrow' => 'Waterfall — הקולקציה', 'heading' => 'קטגוריות מוצרים', 'categories' => array() ),
					array( 'type' => 'featured_products', 'eyebrow' => 'מובחרים', 'heading' => 'מוצרים מומלצים', 'products' => array(), 'view_all_link' => '/shop' ),
					array( 'type' => 'testimonials', 'heading' => 'מה אומרים עלינו', 'items' => array() ),
					array( 'type' => 'tiktok_section', 'brand' => 'waterfall' ),
					array( 'type' => 'articles_section', 'eyebrow' => 'המגזין', 'heading' => 'כתבות, השראה ומדריכים', 'posts' => array() ),
				),
			),

			'ambercom' => array(
				'title'    => 'Ambercom',
				'sections' => array(
					array(
						'type' => 'hero_video',
						'eyebrow' => 'The Amber Collection',
						'heading' => 'Ambercom',
						'heading_emphasis' => 'חמימות שנוגעת בכל פרט.',
						'subheading' => "הקולקציה האמברית — יוקרה, עיצוב נצחי וציפוי Amber Gold ייחודי.\nבלעדי ל-UMBRCOM בישראל.",
						'video' => 0, 'poster_image' => 0,
						'button_1_label' => 'סיפור המותג', 'button_1_link' => '/about',
						'button_2_label' => 'לחנות Ambercom', 'button_2_link' => '/shop',
					),
					array(
						'type' => 'rich_text',
						'content' => "<h3>הבדל שמרגישים בכל מגע</h3><p>Ambercom נולדה מתוך הרצון ליצור ברזים שהם יצירות אמנות — לא רק כלים. כל מוצר מעוצב עם תשומת לב לפרט: מחומרי הגלם ועד ציפוי ה-Amber Gold הייחודי.</p><p>אוסף Ambercom הוא בלעדי ל-UMBRCOM בישראל — עם אחריות מלאה ושירות אישי.</p>",
					),
					array( 'type' => 'featured_products', 'eyebrow' => 'מוצרים נבחרים', 'heading' => 'הקולקציה', 'products' => array(), 'view_all_link' => '/shop' ),
					array( 'type' => 'tiktok_section', 'brand' => 'ambercom' ),
				),
			),

			'about' => array(
				'title'    => 'About',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => 'הסיפור שלנו', 'heading' => 'אודות אמברקום', 'subheading' => '' ),
					array( 'type' => 'rich_text', 'content' => '<p><strong>UMBRCOM</strong> – המותג שמאגד את הכל תחת מטרייה אחת.</p><p>השם <strong>"אמברקום"</strong> נוצר כהשראה מהמילה <strong>"Umbrella"</strong> (מטרייה), על מנת לשדר את הרעיון של חנות שמציעה מגוון רחב של מוצרים – כולם תחת קורת גג אחת. בחנות שלנו תמצאו לא רק איכות, אלא גם מחירים אטרקטיביים במיוחד ושירות שמותאם אישית לצרכים שלכם.</p>' ),
					array( 'type' => 'rich_text', 'content' => '<h3>החזון שלנו</h3><p>החזון של <strong>אמברקום</strong> הוא להעניק לכם את חוויית הקנייה האולטימטיבית – כל מה שאתם צריכים, במקום אחד, במחיר משתלם, עם שירות מקצועי ויחס אישי. המטרה שלנו היא ליצור חוויית קנייה נוחה, פשוטה ומספקת, שבה תוכלו למצוא את כל מה שאתם צריכים מבלי להתפשר על איכות.</p>' ),
					array( 'type' => 'rich_text', 'content' => '<h3>מגוון המוצרים</h3><p>החנות שלנו מציעה מגוון רחב של מוצרים מקטגוריות שונות: טכנולוגיה, עיצוב לבית, פריטים ייחודיים ואקססוריז, כל אחד מהם נבחר בקפידה כדי להבטיח איכות ומחיר משתלם.</p><p>בין אם אתם מחפשים פתרונות טכנולוגיים מתקדמים, פריטי נוי לבית או גאדג\'טים חדשניים – <strong>אמברקום</strong> מציעה לכם את כל זה תחת קורת גג אחת.</p>' ),
				),
			),

			'terms' => array(
				'title'    => 'Terms',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => '', 'heading' => 'תקנון האתר', 'subheading' => '' ),
					array( 'type' => 'rich_text', 'content' => self::terms_html() ),
				),
			),

			'privacy' => array(
				'title'    => 'Privacy',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => '', 'heading' => 'מדיניות פרטיות', 'subheading' => '' ),
					array( 'type' => 'rich_text', 'content' => self::privacy_html() ),
				),
			),

			'returns' => array(
				'title'    => 'Returns',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => '', 'heading' => 'ביטולים והחזרות', 'subheading' => '' ),
					array( 'type' => 'rich_text', 'content' => self::returns_html() ),
				),
			),

			'accessibility-statement' => array(
				'title'    => 'Accessibility Statement',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => 'נגישות', 'heading' => 'הצהרת נגישות', 'subheading' => '' ),
					array( 'type' => 'rich_text', 'content' => self::accessibility_html() ),
				),
			),

			'contact' => array(
				'title'    => 'Contact',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => 'נשמח לשמוע מכם', 'heading' => 'צור קשר', 'subheading' => '' ),
					array(
						'type' => 'info_tiles',
						'heading' => '',
						'style' => 'circles',
						'tiles' => array(
							array( 'icon' => 'ri-phone-line', 'title' => 'טלפון — 03-620-8197', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'tel:036208197' ),
							array( 'icon' => 'ri-whatsapp-line', 'title' => 'וואטסאפ', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'https://wa.me/972036208197' ),
							array( 'icon' => 'ri-mail-line', 'title' => 'office@umbrcom.co.il', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'mailto:office@umbrcom.co.il' ),
						),
					),
				),
			),

			'business' => array(
				'title'    => 'Business',
				'sections' => array(
					array(
						'type' => 'page_header', 'icon' => '', 'eyebrow' => 'Waterfall — B2B', 'heading' => 'מחלקת עסקים',
						'subheading' => 'שותפים עסקיים, קבלנים, מעצבי פנים ויזמי נדל"ן — אנחנו מציעים מחירים מיוחדים, ליווי אישי ומלאי ייעודי לפרויקטים גדולים.',
					),
					array(
						'type' => 'info_tiles', 'heading' => '', 'style' => 'cards',
						'tiles' => array(
							array( 'icon' => 'ri-percent-line', 'title' => 'מחירי סיטונאות', 'text' => 'הנחות מיוחדות על הזמנות גדולות מ-10 יחידות', 'linkLabel' => '', 'linkUrl' => '' ),
							array( 'icon' => 'ri-customer-service-2-line', 'title' => 'נציג אישי', 'text' => 'נציג מכירות ייעודי לכל לקוח עסקי', 'linkLabel' => '', 'linkUrl' => '' ),
							array( 'icon' => 'ri-truck-line', 'title' => 'לוגיסטיקה מותאמת', 'text' => 'אספקה לאתר הבנייה, זמנים גמישים', 'linkLabel' => '', 'linkUrl' => '' ),
						),
					),
				),
			),

			'customer-service' => array(
				'title'    => 'Customer Service',
				'sections' => array(
					array( 'type' => 'page_header', 'icon' => '', 'eyebrow' => '', 'heading' => 'שירות לקוחות', 'subheading' => 'אצלנו ב-Umbrcom תמיכה אמיתית מתחילה לפני הרכישה וממשיכה אחרי קבלתה: צוות מקצועי זמין לכל שאלה טכנית, ביצוע הזמנות, תיאום משלוחים, ואף טיפול בתלונות. ניתן לפנות אלינו בטלפון, במייל או ב-WhatsApp, ואנו מבטיחים מענה מהיר, אדיב ואפקטיבי – כי אצלנו הלקוח תמיד במקום הראשון.' ),
					array(
						'type' => 'info_tiles', 'heading' => '', 'style' => 'circles',
						'tiles' => array(
							array( 'icon' => 'ri-mail-line', 'title' => 'לחץ כאן לשליחת מייל', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'mailto:office@umbrcom.co.il' ),
							array( 'icon' => 'ri-phone-line', 'title' => 'לחץ כאן לשיחה עם נציג', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'tel:036208197' ),
							array( 'icon' => 'ri-whatsapp-line', 'title' => 'לחץ כאן למעבר לוואטסאפ', 'text' => '', 'linkLabel' => '', 'linkUrl' => 'https://wa.me/972036208197' ),
						),
					),
				),
			),

			'warranty' => array(
				'title'    => 'Warranty',
				'sections' => array(
					array(
						'type' => 'page_header', 'icon' => 'ri-shield-check-line', 'eyebrow' => 'Waterfall — אחריות מקיפה', 'heading' => 'הפעלת אחריות',
						'subheading' => "ברוכים הבאים לדף הפעלת האחריות של מוצרי Waterfall.\nאנא מלאו את הפרטים הבאים כדי לרשום את המוצר שלכם ולהפעיל את האחריות המקיפה שלו.",
					),
				),
			),

			'invoice-recovery' => array(
				'title'    => 'Invoice Recovery',
				'sections' => array(
					array(
						'type' => 'page_header', 'icon' => 'ri-file-text-line', 'eyebrow' => 'שירות לקוחות', 'heading' => 'שחזור חשבונית',
						'subheading' => 'לא קיבלתם חשבונית עבור הזמנתכם? מלאו את הפרטים ונשלח אליכם עותק מחדש.',
					),
				),
			),
		);
	}

	private static function terms_html() {
		return <<<'HTML'
<h3>1. כללי</h3>
<p>ברוכים הבאים לאתר אמברקום (UMBRCOM). השימוש באתר ובשירותיו מהווה הסכמה מלאה לתנאים המפורטים להלן. אנא קראו בעיון לפני ביצוע רכישה.</p>
<p>האתר מופעל על ידי אמברקום בע״מ, רחוב שלמה אבן גבירול 69, תל אביב.</p>
<h3>2. זכאות לרכישה</h3>
<p>הרכישה מיועדת לבגירים מגיל 18 ומעלה בעלי כרטיס אשראי תקף בישראל. אמברקום שומרת לעצמה את הזכות לסרב לכל הזמנה לפי שיקול דעתה.</p>
<h3>3. מחירים ותשלום</h3>
<p>כל המחירים באתר כוללים מע״מ (אלא אם צוין אחרת). אמברקום שומרת לעצמה את הזכות לעדכן מחירים בכל עת, ללא הודעה מוקדמת. מחיר המוצר הקובע הוא המחיר שמופיע בעת ביצוע ההזמנה.</p>
<p>התשלום מתבצע באמצעות כרטיסי אשראי (Visa, Mastercard, Amex, Isracard) בסליקה מאובטחת. אמברקום אינה שומרת פרטי כרטיס אשראי.</p>
<h3>4. משלוח ואספקה</h3>
<p>המשלוח מתבצע לכל רחבי הארץ. זמן האספקה הסטנדרטי הוא 3–5 ימי עסקים מרגע אישור ההזמנה. אמברקום אינה אחראית לעיכובים הנגרמים על ידי גורמי שילוח חיצוניים.</p>
<p>משלוח חינם להזמנות מעל ₪200. עלות משלוח סטנדרטי: ₪28. משלוח מהיר: ₪49.</p>
<h3>5. אחריות ושירות</h3>
<p>כל המוצרים מגיעים עם אחריות יצרן. ברזי מטבח וכיור רחצה מהסדרות המסומנות נהנים מאחריות של 7 שנים. מוצרים נוספים — בהתאם למפורט בדף המוצר.</p>
<p>האחריות מכסה פגמי ייצור, אינה חלה על נזק הנגרם משימוש לא תקין, התקנה שגויה או פגעי מים.</p>
<h3>6. קניין רוחני</h3>
<p>כל התוכן באתר — תמונות, טקסטים, לוגו, עיצוב — הוא רכושה הבלעדי של אמברקום ומוגן בזכויות יוצרים. אין להעתיק, לפרסם מחדש או לעשות שימוש מסחרי בתוכן ללא אישור בכתב.</p>
<h3>7. שינויים בתקנון</h3>
<p>אמברקום שומרת לעצמה את הזכות לשנות תנאים אלה בכל עת. המשך השימוש באתר לאחר פרסום השינויים מהווה הסכמה לתנאים המעודכנים.</p>
<h3>8. יצירת קשר</h3>
<p>לשאלות ובירורים: <a href="mailto:office@umbrcom.co.il">office@umbrcom.co.il</a> | 03-620-8197</p>
<p>רחוב שלמה אבן גבירול 69, תל אביב.</p>
HTML;
	}

	private static function privacy_html() {
		return <<<'HTML'
<h3>1. מבוא</h3>
<p>אמברקום בע״מ מחויבת לשמירה על פרטיות המשתמשים. מדיניות זו מסבירה אילו מידע אנו אוספים, כיצד אנו משתמשים בו וכיצד אנו מגנים עליו.</p>
<h3>2. מידע שאנו אוספים</h3>
<p>במהלך הרכישה: שם, כתובת, אימייל, מספר טלפון, כתובת למשלוח. מידע זה נדרש לביצוע ההזמנה ומשלוחה.</p>
<p>מידע טכני: כתובת IP, סוג דפדפן, עמודים שנצפו. נאסף אוטומטית לצרכי שיפור האתר.</p>
<p>אנו אינם שומרים פרטי כרטיס אשראי — הסליקה מתבצעת על ידי גורם חיצוני מאובטח.</p>
<h3>3. שימוש במידע</h3>
<p>המידע משמש לעיבוד הזמנות, אספקת מוצרים, שירות לקוחות, ושליחת עדכונים רלוונטיים (בהסכמתך). אנו לא מוכרים או משכירים מידע אישי לצדדים שלישיים.</p>
<h3>4. קובצי Cookie</h3>
<p>האתר משתמש בקובצי Cookie לשיפור חוויית הגלישה, שמירת העדפות ואנליטיקה. תוכל לנהל הגדרות Cookie בדפדפן שלך בכל עת.</p>
<h3>5. אבטחת מידע</h3>
<p>אנו משתמשים בפרוטוקול SSL להצפנת כל תעבורת הנתונים. שרתינו מאובטחים בסטנדרטים מחמירים. עם זאת, אין אבטחה מוחלטת ברשת האינטרנט.</p>
<h3>6. זכויותיך</h3>
<p>יש לך הזכות לעיין במידע שנשמר אודותיך, לבקש תיקונו, מחיקתו, או הגבלת עיבודו. לפנייה: <a href="mailto:office@umbrcom.co.il">office@umbrcom.co.il</a></p>
<h3>7. יצירת קשר</h3>
<p>ממונה פרטיות: <a href="mailto:office@umbrcom.co.il">office@umbrcom.co.il</a> | 03-620-8197</p>
HTML;
	}

	private static function returns_html() {
		return <<<'HTML'
<h3>מדיניות ביטול עסקה</h3>
<p>בהתאם לחוק הגנת הצרכן, ניתן לבטל עסקה תוך <strong>14 ימים</strong> מיום קבלת המוצר.</p>
<p>ביטול שלא עקב פגם: יחויב דמי ביטול בשיעור 5% ממחיר העסקה, לא יותר מ-100 ₪. ביטול עקב פגם: ללא חיוב.</p>
<h3>תנאי ההחזרה</h3>
<ul>
<li>המוצר חייב להיות באריזתו המקורית ולא נעשה בו שימוש</li>
<li>יש לצרף חשבונית קנייה</li>
<li>מוצרים שהותקנו אינם ניתנים להחזרה (אלא בגלל פגם)</li>
<li>מוצרים מוזמנים במיוחד אינם ניתנים לביטול</li>
</ul>
<h3>תהליך ההחזרה</h3>
<ol>
<li><strong>פנה אלינו</strong> — שלח אימייל ל-office@umbrcom.co.il או התקשר ל-03-620-8197 עם פרטי ההזמנה.</li>
<li><strong>אישור ובדיקה</strong> — נבדוק את פרטי ההזמנה ונאשר את הבקשה תוך יום עסקים אחד.</li>
<li><strong>אריזה ומשלוח</strong> — יש לארוז את המוצר היטב ולשלוח לכתובת שנמסור לך. עלויות המשלוח חזרה חלות על הלקוח (אלא אם פגם).</li>
<li><strong>זיכוי</strong> — לאחר קבלת המוצר ובדיקתו, הזיכוי יתבצע לאמצעי התשלום המקורי תוך 3–5 ימי עסקים.</li>
</ol>
<h3>מוצרים פגומים</h3>
<p>קיבלת מוצר פגום? נשמח לטפל בכך מיידית — נחליף את המוצר ללא עלות, כולל איסוף. אנא צלם את הפגם ושלח לנו בהקדם.</p>
<h3>צריך עזרה?</h3>
<p>📧 <a href="mailto:office@umbrcom.co.il">office@umbrcom.co.il</a><br />📞 <a href="tel:+97236208197">03-620-8197</a><br />ימים א׳–ה׳, 09:00–17:00</p>
HTML;
	}

	private static function accessibility_html() {
		return <<<'HTML'
<h3>מחויבות לנגישות</h3>
<p>אמברקום בע"מ (UMBRCOM) מחויבת לספק שירות שווה ואיכותי לכל לקוחותיה, לרבות אנשים עם מוגבלויות. אנו פועלים לעמידה בדרישות תקנות שוויון זכויות לאנשים עם מוגבלות (התאמות נגישות לשירות), התשע"ג-2013, ובהנחיות WCAG 2.1 ברמה AA.</p>
<h3>מאפייני הנגישות באתר</h3>
<ul>
<li>ניווט מלא מהמקלדת — ללא שימוש בעכבר</li>
<li>תמיכה בתוכנות קוראי מסך (NVDA, JAWS, VoiceOver)</li>
<li>הגדלת טקסט עד 200% ללא אובדן תוכן</li>
<li>ניגודיות צבעים עומדת בתקן 4.5:1 לפחות</li>
<li>תיאורי alt לכל התמונות המשמעותיות</li>
<li>כל הטפסים מסומנים עם label מתאים</li>
<li>מבנה כותרות (H1-H6) היררכי ועקבי</li>
</ul>
<h3>כלי הנגישות באתר</h3>
<p>באתר זמין כפתור נגישות (אייקון גלגל השיניים בצד הימני של המסך) המאפשר: שינוי גודל הגופן, הפעלת ניגודיות גבוהה, והדגשת קישורים.</p>
<h3>מידע ליצירת קשר בנושא נגישות</h3>
<p>גילינו תקלה? יש לכם הצעה לשיפור? נשמח לשמוע.</p>
<p><strong>רכז נגישות: אמברקום בע״מ</strong><br />טל: <a href="tel:+97236208197">03-620-8197</a><br />דוא"ל: <a href="mailto:info@umbrcom.co.il">info@umbrcom.co.il</a></p>
<h3>עדכון אחרון</h3>
<p>הצהרה זו עודכנה לאחרונה ביוני 2025.</p>
HTML;
	}
}
