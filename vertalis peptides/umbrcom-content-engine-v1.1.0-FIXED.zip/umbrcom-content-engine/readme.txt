=== UMBRCOM Content Engine ===
Contributors: velocity72
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Requires plugins: woocommerce
Stable tag: 2.0.0
License: GPLv2 or later

Turns this WordPress + WooCommerce install into the headless CMS/commerce
backend for the UMBRCOM React storefront (Waterfall + Ambercom).

**Requires only WooCommerce.** Every custom field — the Page Builder,
product fields, Series, Site Settings, category images — is built
in-house on core WordPress APIs (meta boxes, `wp.media`, `wp-color-picker`,
`register_rest_field`, the WooCommerce Store API). No ACF, no other
third-party field/page-builder plugin, no extra license.

== What this plugin adds ==

1. **Page Builder** — every WordPress Page gets a "Page Builder" meta box:
   add / remove / reorder sections (Hero Video, Trust Strip, Categories
   Grid, Featured Products, Testimonials, TikTok Section, Articles Teaser,
   Rich Text, CTA Banner) with the ↑ / ↓ / × buttons on each one. The
   frontend renders whatever's there automatically.

2. **Series** — a "Series" item in the admin menu (Hydra, Dett, Sora…)
   with tagline, description, banner image, accent color, and a linked
   product category. Powers the /series page.

3. **Storefront product fields** — every WooCommerce product gets a
   "Storefront Details" panel: spec table, 3D model (.glb/.usdz), AR
   toggle, badge text, "new" flag, curated related accessories.
   Colors/finishes use WooCommerce's native Attributes + Variations — the
   correct WooCommerce-native way to do that — not a custom field.

4. **Category Display Settings** — a tile image + label override on every
   product category (Products → Categories → edit a category), so
   swapping a category photo is a wp-admin job, not a code change.

5. **Site Settings** — one global admin page (own top-level menu item) for
   contact info, social links, brand colors, both hero videos, header nav
   links, TikTok handles/videos, and footer content.

6. **REST wiring** — all of the above is exposed:
   - `GET /wp-json/umbrcom/v1/settings` — Site Settings.
   - `GET /wp-json/umbrcom/v1/nav` — live product categories + Series.
   - `GET /wp-json/wp/v2/pages?slug=...&_fields=id,slug,title,umbrcom_sections`
     — a page's Page Builder sections.
   - `GET /wp-json/wc/store/v1/products` / `/products/{id}` — WooCommerce's
     public, key-less Store API, extended with an `umbrcom` data block
     carrying the storefront fields above.
   - CORS headers so the React app can call all of this from its own
     domain (configure allowed origins in wp-config.php — see
     `includes/class-rest-cors.php`).

== Setup ==

See SETUP.md in the plugin folder for the full walkthrough.
