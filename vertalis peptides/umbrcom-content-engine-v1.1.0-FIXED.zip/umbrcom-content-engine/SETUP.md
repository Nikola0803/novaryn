# UMBRCOM Content Engine — Setup

**Requires only WooCommerce.** No ACF, no other field/page-builder plugin.

## 1. Install

1. WooCommerce (if not already active).
2. Upload & activate `umbrcom-content-engine.zip` as a normal plugin.

**That's it.** Activation automatically creates a WordPress Page — already
filled in with today's real content — for every page the React app has:
Home, Ambercom, About, Contact, Terms, Privacy, Returns, Accessibility
Statement, Business, Customer Service, Warranty, Invoice Recovery. Open
**Pages → All Pages** right after activating and they're all there, ready
to edit. Nothing is blank.

If you ever need to re-run this (e.g. after adding a brand-new page to the
manifest in a future update), there's a **"Sync Pages Now"** button at the
top of the Site Settings screen — it only ever creates pages that don't
exist yet; it never touches or overwrites a page you've already edited.

## 2. Where everything lives

| What | Where |
|---|---|
| Home, About, Contact, Terms, etc. — any page's actual content | **Pages → All Pages → [page] → Page Builder** meta box |
| Global settings (phone, colors, nav links, TikTok, footer) | **Site Settings** (own top-level menu item) |
| Product specs, 3D model, badges, description text | **Products → [product] → Storefront Details** meta box |
| Product colors/finishes | **Products → [product] → Product data → Attributes/Variations** (native WooCommerce) |
| Category photos | **Products → Categories → [category] → Tile Image** |
| Series (Hydra, Dett, Sora…) | **Series** (own top-level menu item) |

## 3. Products — colors, gallery, specs, everything on the product page

- **Colors/finishes**: create a **Variable product**, add a "Color"
  attribute, tick "Used for variations", add one variation per finish.
  Each variation can have its own price, stock, and image.
- **Gallery**: the product's native **Product Gallery** field.
- **Reviews/rating**: WooCommerce's native **Reviews** (enable per-product
  under Product data → Advanced) — the star rating and review count on
  the product page are pulled from here automatically, not a custom field.
- **Everything else visible on the product page** now has a matching
  field in the **Storefront Details** panel:
  - Highlight cards (the 3 icon cards above the buy box)
  - Short description (the highlighted line next to the SKU)
  - Description tab: paragraphs + feature bullets
  - Specs tab: the spec table
  - Shipping tab: shipping / returns / warranty blocks
  - 3D model (.glb/.usdz) + AR toggle
  - Badge text, "new" flag, related accessories
  - Brand label (the "— Waterfall" next to the category)

  Every one of these has a sensible default already in the code, so a
  product with nothing filled in still looks exactly like it does today —
  fill in a field only when you want to override that product specifically.

## 4. Categories

Products → Categories → edit a category → **Tile Image** + optional
**Display Label Override**.

## 5. Series

Admin menu → **Series** → Add New → Tagline, Description, Banner Image,
Accent Color, **Linked Product Category**, and tick **"Show as the large
featured banner"** on exactly one series.

## 6. Building/editing a page

Open any Page → scroll to **Page Builder** → **+ Add Section** → pick a
layout → **+ Add Section** button. Reorder with ↑ / ↓, remove with ×.

| Layout | Use for |
|---|---|
| Page Header / Banner | The eyebrow + title banner at the top of a content page |
| Hero — Video Banner | The homepage / brand-page video hero |
| Trust Strip | The perks row |
| Categories Grid | The 3-tile category showcase |
| Featured Products | A hand-picked row of products (search-and-add) |
| Testimonials | Customer quotes |
| TikTok Section | Pulls videos from the brand's TikTok settings |
| Info Tiles | Icon+title+text grid — benefit lists, contact methods |
| Articles / Blog Teaser | The magazine-style article teaser |
| Rich Text Block | Freeform content — basic HTML: `<p>`, `<b>`, `<i>`, `<a>`, `<ul>/<li>`, `<h3>` |
| CTA Banner | A full-width call-to-action strip |

**Pages with a form** (Contact, Business, Customer Service, Warranty,
Invoice Recovery) — the form itself (its fields, its submit behavior)
isn't editable from wp-admin; Page Builder edits content, not form logic.
Everything *around* the form — the header, intro copy, contact-method
tiles — is fully editable the same as any other page.

## 7. Site Settings

Admin menu → **Site Settings** — Contact & Social, Brand Colors & Logos
(including both homepage hero videos), Header Navigation, TikTok Sections,
Footer, plus the **Sync Pages Now** button described above.

## 8. CORS (production)

```php
define( 'UMBRCOM_CE_ALLOWED_ORIGINS', array(
    'https://umbrcom.co.il',
    'https://www.umbrcom.co.il',
) );
```

## 9. Frontend

```
# umbrc/.env
VITE_WP_API_URL=https://your-wp-domain.co.il/wp-json
```

See `src/lib/wp-api.ts` and `CHANGES.md` in the React project.

## Notes on a couple of deliberate simplifications

- **Rich Text Block** is a plain textarea that accepts basic HTML, not a
  full TinyMCE editor — a real rich-text editor doesn't survive being
  cloned inside a repeater reliably.
- **Categories Grid**'s category picker is a checkbox list, not a custom
  drag-orderable list.
- Reordering uses ↑ / ↓ buttons instead of drag-and-drop — more reliable
  across browsers with zero extra dependencies.

---

## v2.1 — Product content fields + Pelecard

### New "Storefront Details" fields (per product)

- **סרטון מוצר** — paste any YouTube link (watch?v=, youtu.be, Shorts); embedded on the product page.
- **סקירת AI** — free text, blank line = new paragraph. Rendered as a regular content section.
- **נתונים טכניים** — HTML/table field. Paste raw HTML *or* paste cells straight
  from Excel/Sheets (2–4 columns, tab-separated) — the paste is auto-converted to a
  styled HTML table on save (first row becomes the header). Sanitized with a strict
  wp_kses allowlist, so it's safe to render as-is.
- **תכולת האריזה** — free text, one item per line; rendered as a checklist.
- **אחריות** — free text warranty terms.
- The original label/value **מפרט טכני** repeater still exists alongside נתונים
  טכניים — use whichever fits the product (both tabs only appear when filled).

All sections appear on the product page only when filled. Data flows through the
same `umbrcom` block on the Store API product response (`package_contents` is now
a plain string; legacy repeater data is auto-converted).

### Pelecard payment gateway

Settings: **Site Settings → Pelecard** (wp-admin). Fill in Terminal / API User /
API Password from Pelecard support, set Frontend URL to where the React app is
served, tick Enabled.

Flow (aligned with the integration proven in production on the Mashiach
terminal — including its Cloudflare lesson):
1. `POST /wp-json/umbrcom/v1/checkout` — React sends cart + customer + shipping
   method; the plugin builds a real WooCommerce order (server-side prices),
   calls Pelecard `PaymentGW/init` (gateway21, `ServerSide*FeedbackURL` field
   names, GET feedback for the static SPA) and returns the hosted payment page
   URL. Max תשלומים are tiered by amount (₪150→6, ₪1500→9, ₪2500→12), capped
   by the admin setting.
2. Shopper pays on Pelecard's page (PCI — no card data touches our servers).
3. Verification NEVER depends on callbacks arriving. The result page (and any
   refresh of it) triggers verification that tries, in order:
   - `ValidateByUniqueKey` when the browser return carried a ConfirmationKey;
   - a `GetTransaction` PULL — we fetch the transaction from Pelecard
     ourselves and match `ParamX` = order ID, with an amount sanity check.
   This survives Cloudflare/WAF silently eating Pelecard's server POST (which
   is exactly what happened on the Mashiach site). The notify endpoint still
   exists and handles all callback shapes (JSON / ResultData / form / GET) as
   a bonus, and rich card meta (approval number, last digits, card type,
   payments, voucher) is saved to the DB BEFORE `payment_complete()` so any
   invoicing/ERP hooks see complete data.

Optional hardening: give Pelecard support the notify URL
(`https://<wp-domain>/wp-json/umbrcom/v1/pelecard/notify`) and, if the WP
domain sits behind Cloudflare, whitelist Pelecard's IPs — but orders settle
correctly even without it thanks to the pull.

Note: the shipping prices in `Umbrcom_CE_Pelecard::SHIPPING_METHODS` must stay
in sync with `SHIPPING_OPTIONS` in `src/pages/checkout/page.tsx`.
