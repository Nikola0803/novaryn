<?php
/**
 * umbrcom-content-engine — Pelecard checkout module (July 2026)
 * =====================================================================
 * Implements the three REST routes the React storefront already calls:
 *
 *   POST /umbrcom/v1/checkout          → create Woo order + Pelecard init,
 *                                        returns the hosted-page redirect URL
 *   POST /umbrcom/v1/pelecard/confirm  → validate the redirect params WITH
 *                                        PELECARD (never trusted raw), mark paid
 *   GET  /umbrcom/v1/pelecard/status   → order status (thank-you page refresh /
 *                                        server-notify already handled it)
 *
 * Ported from the proven Waterfall→Mashiach integration:
 *  - gateway21 hosted payment page (PaymentGW/init)
 *  - PULL-BASED verification: we never mark an order paid off redirect params
 *    alone; we ask Pelecard (ValidateByUniqueKey + GetTransaction). This is
 *    also why Cloudflare blocking Pelecard's inbound server POST doesn't
 *    matter — the shopper's return trip triggers our own outbound check.
 *  - Transaction meta is saved BEFORE payment_complete() so invoicing/ERP
 *    hooks fired by payment_complete see the Pelecard data.
 *
 * CREDENTIALS — define in wp-config.php (never hardcode in the plugin):
 *   define( 'UMBRCOM_PELECARD_TERMINAL', '...' );
 *   define( 'UMBRCOM_PELECARD_USER',     '...' );
 *   define( 'UMBRCOM_PELECARD_PASSWORD', '...' );
 * These must be UMBRCOM's own terminal — do not reuse another business's.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const UMBRCOM_STOREFRONT_URL = 'https://umbrcom.co.il';
const UMBRCOM_PELECARD_API   = 'https://gateway21.pelecard.biz/PaymentGW';

/** Shipping — MUST mirror src/pages/checkout/page.tsx on the storefront. */
const UMBRCOM_SHIPPING = array(
	'standard' => array( 'label' => 'משלוח סטנדרטי', 'price' => 28 ),
	'express'  => array( 'label' => 'משלוח מהיר', 'price' => 49 ),
	'free'     => array( 'label' => 'משלוח חינם', 'price' => 0, 'min_order' => 200 ),
);

/** Max installments by order total (₪). ⚠️ Copied from the Waterfall/Mashiach
 *  terminal rules — CONFIRM WITH BEN these tiers apply to UMBRCOM's terminal. */
function umbrcom_max_payments( float $total ): int {
	if ( $total >= 2500 ) return 12;
	if ( $total >= 1500 ) return 9;
	if ( $total >= 150 )  return 6;
	return 1;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'umbrcom/v1', '/checkout', array(
		'methods'             => 'POST',
		'callback'            => 'umbrcom_rest_checkout',
		'permission_callback' => '__return_true',
	) );
	register_rest_route( 'umbrcom/v1', '/pelecard/confirm', array(
		'methods'             => 'POST',
		'callback'            => 'umbrcom_rest_pelecard_confirm',
		'permission_callback' => '__return_true',
	) );
	register_rest_route( 'umbrcom/v1', '/pelecard/status', array(
		'methods'             => 'GET',
		'callback'            => 'umbrcom_rest_pelecard_status',
		'permission_callback' => '__return_true',
	) );
} );

/* ────────────────────────────────────────────────────────────────────────
 * POST /umbrcom/v1/checkout
 * ──────────────────────────────────────────────────────────────────────── */
function umbrcom_rest_checkout( WP_REST_Request $req ) {
	if ( ! defined( 'UMBRCOM_PELECARD_TERMINAL' ) || ! defined( 'UMBRCOM_PELECARD_USER' ) || ! defined( 'UMBRCOM_PELECARD_PASSWORD' ) ) {
		return new WP_REST_Response( array( 'error' => 'סליקה אינה מוגדרת עדיין. פנו אלינו טלפונית להשלמת ההזמנה.' ), 503 );
	}

	$items    = $req->get_param( 'items' );
	$customer = $req->get_param( 'customer' );
	$shipping = (string) $req->get_param( 'shipping_method' );

	if ( empty( $items ) || ! is_array( $items ) || empty( $customer['email'] ) || ! is_email( $customer['email'] ) ) {
		return new WP_REST_Response( array( 'error' => 'פרטי הזמנה חסרים.' ), 400 );
	}
	if ( ! isset( UMBRCOM_SHIPPING[ $shipping ] ) ) {
		$shipping = 'standard';
	}

	// ── Build the order from REAL catalog data — client prices are never trusted.
	$order = wc_create_order();
	$subtotal = 0.0;

	foreach ( $items as $line ) {
		$product = wc_get_product( absint( $line['id'] ?? 0 ) );
		$qty     = max( 1, min( 99, absint( $line['quantity'] ?? 1 ) ) );
		if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			$order->delete( true );
			return new WP_REST_Response( array( 'error' => 'אחד המוצרים בסל אינו זמין כרגע. רעננו את הסל ונסו שוב.' ), 409 );
		}
		$order->add_product( $product, $qty );
		$subtotal += (float) $product->get_price() * $qty;
	}

	// ── Shipping (server-side recompute; "free" under the minimum falls back to standard).
	$ship = UMBRCOM_SHIPPING[ $shipping ];
	$ship_cost = (float) $ship['price'];
	if ( 'free' === $shipping && $subtotal < UMBRCOM_SHIPPING['free']['min_order'] ) {
		$ship      = UMBRCOM_SHIPPING['standard'];
		$ship_cost = (float) $ship['price'];
	}
	$ship_item = new WC_Order_Item_Shipping();
	$ship_item->set_method_title( $ship['label'] );
	$ship_item->set_total( $ship_cost );
	$order->add_item( $ship_item );

	// ── Addresses.
	$addr = array(
		'first_name' => sanitize_text_field( $customer['first_name'] ?? '' ),
		'last_name'  => sanitize_text_field( $customer['last_name'] ?? '' ),
		'email'      => sanitize_email( $customer['email'] ),
		'phone'      => sanitize_text_field( $customer['phone'] ?? '' ),
		'address_1'  => sanitize_text_field( $customer['address'] ?? '' ),
		'city'       => sanitize_text_field( $customer['city'] ?? '' ),
		'postcode'   => sanitize_text_field( $customer['zip'] ?? '' ),
		'country'    => 'IL',
	);
	$order->set_address( $addr, 'billing' );
	$order->set_address( $addr, 'shipping' );
	if ( ! empty( $customer['notes'] ) ) {
		$order->set_customer_note( sanitize_textarea_field( $customer['notes'] ) );
	}

	$order->set_payment_method( 'pelecard' );
	$order->set_payment_method_title( 'כרטיס אשראי (Pelecard)' );
	$order->calculate_totals();
	$order->update_status( 'pending', 'ממתין לתשלום Pelecard.' );

	$total     = (float) $order->get_total();
	$order_id  = $order->get_id();
	$order_key = $order->get_order_key();

	// ── Pelecard PaymentGW/init.
	$result_url = UMBRCOM_STOREFRONT_URL . '/checkout/result?order_id=' . $order_id . '&order_key=' . rawurlencode( $order_key );
	$init = array(
		'terminal'                    => UMBRCOM_PELECARD_TERMINAL,
		'user'                        => UMBRCOM_PELECARD_USER,
		'password'                    => UMBRCOM_PELECARD_PASSWORD,
		'GoodURL'                     => $result_url,
		'ErrorURL'                    => $result_url,
		'CancelURL'                   => UMBRCOM_STOREFRONT_URL . '/checkout',
		// Server-side notify URLs included for completeness; verification is
		// pull-based so a Cloudflare-blocked inbound POST is harmless.
		'ServerSideGoodFeedbackURL'   => rest_url( 'umbrcom/v1/pelecard/notify' ),
		'ServerSideErrorFeedbackURL'  => rest_url( 'umbrcom/v1/pelecard/notify' ),
		'ActionType'                  => 'J4',
		'Currency'                    => '1',                       // ILS
		'Total'                       => (string) round( $total * 100 ), // agorot
		'MaxPayments'                 => (string) umbrcom_max_payments( $total ),
		'MinPayments'                 => '1',
		'Language'                    => 'HE',
		'UserKey'                     => $order_key,
		'ParamX'                      => $order_id . '|' . $order_key,
		'FeedbackDataTransferMethod'  => 'GET',
		'TopText'                     => 'UMBRCOM — תשלום מאובטח',
		'BottomText'                  => 'הזמנה #' . $order->get_order_number(),
	);

	$resp = wp_remote_post( UMBRCOM_PELECARD_API . '/init', array(
		'timeout' => 25,
		'headers' => array( 'Content-Type' => 'application/json' ),
		'body'    => wp_json_encode( $init ),
	) );

	$body = is_wp_error( $resp ) ? null : json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( empty( $body['URL'] ) || ( isset( $body['StatusCode'] ) && '000' !== $body['StatusCode'] ) ) {
		$order->add_order_note( 'Pelecard init נכשל: ' . ( $body['ErrorMessage'] ?? ( is_wp_error( $resp ) ? $resp->get_error_message() : 'unknown' ) ) );
		return new WP_REST_Response( array( 'error' => 'שגיאה בחיבור לחברת הסליקה. נסו שוב בעוד רגע.' ), 502 );
	}

	$order->update_meta_data( '_pelecard_init_transaction_id', $body['TransactionId'] ?? '' );
	$order->save();

	return new WP_REST_Response( array(
		'order_id'     => $order_id,
		'order_key'    => $order_key,
		'redirect_url' => $body['URL'],
		'total'        => $total,
	), 200 );
}

/* ────────────────────────────────────────────────────────────────────────
 * POST /umbrcom/v1/pelecard/confirm — pull-based verification
 * ──────────────────────────────────────────────────────────────────────── */
function umbrcom_rest_pelecard_confirm( WP_REST_Request $req ) {
	$order = umbrcom_load_order_checked( $req->get_param( 'order_id' ), (string) $req->get_param( 'order_key' ) );
	if ( ! $order ) {
		return new WP_REST_Response( array( 'status' => 'invalid', 'order_id' => 0, 'order_number' => '', 'total' => 0, 'email' => '', 'first_name' => '' ), 200 );
	}

	// Already settled (e.g. server notify beat the shopper, or a refresh).
	if ( $order->is_paid() ) {
		return umbrcom_order_result( $order, 'paid' );
	}

	$status_code    = (string) $req->get_param( 'status_code' );
	$transaction_id = sanitize_text_field( (string) $req->get_param( 'transaction_id' ) );

	if ( '000' !== $status_code || '' === $transaction_id ) {
		$order->update_status( 'failed', 'Pelecard החזיר סטטוס ' . $status_code );
		return umbrcom_order_result( $order, 'failed' );
	}

	// ── Never trust the redirect: ask Pelecard for the transaction itself.
	$resp = wp_remote_post( UMBRCOM_PELECARD_API . '/GetTransaction', array(
		'timeout' => 25,
		'headers' => array( 'Content-Type' => 'application/json' ),
		'body'    => wp_json_encode( array(
			'terminal'      => UMBRCOM_PELECARD_TERMINAL,
			'user'          => UMBRCOM_PELECARD_USER,
			'password'      => UMBRCOM_PELECARD_PASSWORD,
			'TransactionId' => $transaction_id,
		) ),
	) );
	$body = is_wp_error( $resp ) ? null : json_decode( wp_remote_retrieve_body( $resp ), true );
	$tx   = $body['ResultData'] ?? null;

	$expected_agorot = (int) round( (float) $order->get_total() * 100 );
	$paid_agorot     = (int) ( $tx['DebitTotal'] ?? $tx['Total'] ?? -1 );
	$tx_ok           = $tx
		&& ( '000' === ( $body['StatusCode'] ?? '' ) || '000' === ( $tx['StatusCode'] ?? '' ) )
		&& $paid_agorot === $expected_agorot
		&& false !== strpos( (string) ( $tx['AdditionalDetailsParamX'] ?? '' ), (string) $order->get_id() );

	if ( ! $tx_ok ) {
		$order->update_status( 'on-hold', 'Pelecard: אימות עסקה נכשל (TransactionId ' . $transaction_id . ') — בדיקה ידנית נדרשת.' );
		return umbrcom_order_result( $order, 'pending' );
	}

	// ── Meta BEFORE payment_complete, so invoicing/ERP hooks see it.
	$order->update_meta_data( '_pelecard_transaction_id', $transaction_id );
	$order->update_meta_data( '_pelecard_confirmation_key', sanitize_text_field( (string) $req->get_param( 'confirmation_key' ) ) );
	$order->update_meta_data( '_pelecard_card_token', sanitize_text_field( (string) $req->get_param( 'token' ) ) );
	$order->update_meta_data( '_pelecard_voucher', sanitize_text_field( (string) ( $tx['VoucherId'] ?? '' ) ) );
	$order->save();

	$order->payment_complete( $transaction_id );
	$order->add_order_note( 'תשלום Pelecard אומת (GetTransaction). שובר: ' . ( $tx['VoucherId'] ?? '—' ) );

	return umbrcom_order_result( $order, 'paid' );
}

/* ────────────────────────────────────────────────────────────────────────
 * GET /umbrcom/v1/pelecard/status
 * ──────────────────────────────────────────────────────────────────────── */
function umbrcom_rest_pelecard_status( WP_REST_Request $req ) {
	$order = umbrcom_load_order_checked( $req->get_param( 'order_id' ), (string) $req->get_param( 'order_key' ) );
	if ( ! $order ) {
		return new WP_REST_Response( array( 'status' => 'invalid', 'order_id' => 0, 'order_number' => '', 'total' => 0, 'email' => '', 'first_name' => '' ), 200 );
	}
	$status = $order->is_paid() ? 'paid' : ( 'failed' === $order->get_status() ? 'failed' : 'pending' );
	return umbrcom_order_result( $order, $status );
}

/* ── helpers ─────────────────────────────────────────────────────────── */

function umbrcom_load_order_checked( $order_id, string $order_key ): ?WC_Order {
	$order = wc_get_order( absint( $order_id ) );
	if ( ! $order || '' === $order_key || ! hash_equals( $order->get_order_key(), $order_key ) ) {
		return null;
	}
	return $order;
}

function umbrcom_order_result( WC_Order $order, string $status ): WP_REST_Response {
	return new WP_REST_Response( array(
		'status'       => $status,
		'order_id'     => $order->get_id(),
		'order_number' => $order->get_order_number(),
		'total'        => (float) $order->get_total(),
		'email'        => $order->get_billing_email(),
		'first_name'   => $order->get_billing_first_name(),
	), 200 );
}