/**
 * UMBRCOM Content Engine — admin field kit.
 * Powers: generic repeaters, the Page Builder's add/remove/reorder
 * sections, image/file pickers (wp.media), color pickers (wp-color-picker,
 * both core WordPress), and the relationship field's search-and-add pills.
 *
 * No third-party JS libraries — just jQuery (bundled with wp-admin) and
 * core WP admin APIs.
 */
(function ($) {
	'use strict';

	function initColorPickers( $scope ) {
		$scope.find( '.umbrcom-color-field' ).each( function () {
			if ( ! $( this ).hasClass( 'wp-color-picker' ) ) {
				$( this ).wpColorPicker();
			}
		} );
	}

	/** Clones a <template>'s content, swapping every occurrence of `token`
	 *  for `index`, and returns the single root element it produced. */
	function cloneTemplate( templateEl, token, index ) {
		var wrapper = document.createElement( 'div' );
		wrapper.appendChild( document.importNode( templateEl.content, true ) );
		wrapper.innerHTML = wrapper.innerHTML.split( token ).join( index );
		return wrapper.firstElementChild;
	}

	/* ── Generic repeaters (spec table, perks, testimonials, nav links, TikTok videos, footer columns/links) ── */

	$( document ).on( 'click', '.umbrcom-add-row', function ( e ) {
		e.preventDefault();
		var $repeater  = $( this ).closest( '.umbrcom-repeater' );
		var token      = $repeater.attr( 'data-index-token' );
		var nextIndex  = parseInt( $repeater.attr( 'data-next-index' ), 10 ) || 0;
		var templateEl = $repeater.children( 'template.umbrcom-row-template' )[0];
		if ( ! templateEl ) {
			return;
		}
		var newRow = cloneTemplate( templateEl, token, nextIndex );
		$repeater.children( '.umbrcom-repeater-rows' ).append( newRow );
		$repeater.attr( 'data-next-index', nextIndex + 1 );
		initColorPickers( $( newRow ) );
	} );

	/* ── Excel paste zone (July 2026): paste a table copied from Excel /
	   Google Sheets into .umbrcom-tsv-paste and every row becomes a
	   repeater row in the repeater that follows it. Prefers the HTML
	   clipboard flavor (real <table>), falls back to tab-separated text. ── */

	function clipboardToRows( dt ) {
		var html = dt.getData( 'text/html' );
		if ( html && /<table/i.test( html ) ) {
			var doc = new DOMParser().parseFromString( html, 'text/html' );
			return Array.prototype.map.call( doc.querySelectorAll( 'tr' ), function ( tr ) {
				return Array.prototype.map.call( tr.querySelectorAll( 'td,th' ), function ( c ) {
					return ( c.textContent || '' ).replace( /\s+/g, ' ' ).trim();
				} );
			} );
		}
		var text = dt.getData( 'text/plain' ) || '';
		return text.split( /\r?\n/ ).map( function ( line ) {
			return line.split( '\t' ).map( function ( c ) { return c.trim(); } );
		} );
	}

	$( document ).on( 'paste', '.umbrcom-tsv-paste', function ( e ) {
		var dt = ( e.originalEvent || e ).clipboardData;
		if ( ! dt ) {
			return;
		}
		var rows = clipboardToRows( dt ).filter( function ( cells ) {
			return cells.join( '' ).trim() !== '';
		} );
		if ( ! rows.length ) {
			return;
		}
		e.preventDefault();

		var $repeater = $( this ).closest( '.umbrcom-field' ).nextAll( '.umbrcom-repeater' ).first();
		var templateEl = $repeater.children( 'template.umbrcom-row-template' )[0];
		if ( ! templateEl ) {
			return;
		}
		var token = $repeater.attr( 'data-index-token' );
		var index = parseInt( $repeater.attr( 'data-next-index' ), 10 ) || 0;
		var added = 0;

		rows.forEach( function ( cells ) {
			var newRow  = cloneTemplate( templateEl, token, index );
			var $inputs = $( newRow ).find( 'input[type="text"], textarea' );
			if ( ! $inputs.length ) {
				return;
			}
			$inputs.eq( 0 ).val( cells[0] || '' );
			if ( $inputs.length > 1 ) {
				$inputs.eq( 1 ).val( cells.slice( 1 ).join( ' — ' ) );
			}
			$repeater.children( '.umbrcom-repeater-rows' ).append( newRow );
			initColorPickers( $( newRow ) );
			index++;
			added++;
		} );

		$repeater.attr( 'data-next-index', index );
		$( this ).val( '' ).attr( 'placeholder', '✓ נוספו ' + added + ' שורות — אפשר להדביק עוד' );
	} );

	/* ── Row / section shared controls (remove, move up/down) ── */

	$( document ).on( 'click', '.umbrcom-row-remove', function ( e ) {
		e.preventDefault();
		if ( window.confirm( 'להסיר?' ) ) {
			$( this ).closest( '.umbrcom-row, .umbrcom-section' ).remove();
		}
	} );

	$( document ).on( 'click', '.umbrcom-row-up', function ( e ) {
		e.preventDefault();
		var $item = $( this ).closest( '.umbrcom-row, .umbrcom-section' );
		var $prev = $item.prev( '.umbrcom-row, .umbrcom-section' );
		if ( $prev.length ) {
			$item.insertBefore( $prev );
		}
	} );

	$( document ).on( 'click', '.umbrcom-row-down', function ( e ) {
		e.preventDefault();
		var $item = $( this ).closest( '.umbrcom-row, .umbrcom-section' );
		var $next = $item.next( '.umbrcom-row, .umbrcom-section' );
		if ( $next.length ) {
			$item.insertAfter( $next );
		}
	} );

	/* ── Page Builder: add a new section of the chosen type ── */

	$( document ).on( 'click', '.umbrcom-add-section', function ( e ) {
		e.preventDefault();
		var $builder = $( this ).closest( '.umbrcom-page-builder' );
		var type     = $builder.find( '.umbrcom-add-section-type' ).val();
		var $template = $builder.children( 'template.umbrcom-section-template' ).filter( function () {
			return $( this ).attr( 'data-layout' ) === type;
		} );
		if ( ! $template.length ) {
			return;
		}
		var nextIndex  = parseInt( $builder.attr( 'data-next-index' ), 10 ) || 0;
		var newSection = cloneTemplate( $template[0], '__L1_INDEX__', nextIndex );
		$builder.children( '.umbrcom-sections-list' ).append( newSection );
		$builder.attr( 'data-next-index', nextIndex + 1 );
		initColorPickers( $( newSection ) );
	} );

	/* ── Media: image picker ── */

	$( document ).on( 'click', '.umbrcom-media-choose', function ( e ) {
		e.preventDefault();
		var $field = $( this ).closest( '.umbrcom-media-field' );
		var frame  = wp.media( { multiple: false } );
		frame.on( 'select', function () {
			var attachment = frame.state().get( 'selection' ).first().toJSON();
			var previewUrl = ( attachment.sizes && attachment.sizes.medium ) ? attachment.sizes.medium.url : attachment.url;
			$field.find( '.umbrcom-media-value' ).val( attachment.id );
			$field.find( '.umbrcom-media-preview img' ).attr( 'src', previewUrl );
			$field.find( '.umbrcom-media-preview' ).show();
			$field.find( '.umbrcom-media-choose' ).text( 'החלפת תמונה' );
			$field.find( '.umbrcom-media-remove' ).show();
		} );
		frame.open();
	} );

	/* ── Media: generic file picker (3D models, videos) ── */

	$( document ).on( 'click', '.umbrcom-media-choose-file', function ( e ) {
		e.preventDefault();
		var $field = $( this ).closest( '.umbrcom-media-field' );
		var mime   = $field.attr( 'data-mime-types' );
		var opts   = { multiple: false };
		if ( mime ) {
			opts.library = { type: mime };
		}
		var frame = wp.media( opts );
		frame.on( 'select', function () {
			var attachment = frame.state().get( 'selection' ).first().toJSON();
			$field.find( '.umbrcom-media-value' ).val( attachment.id );
			$field.find( '.umbrcom-media-filename' ).text( attachment.filename || attachment.url.split( '/' ).pop() );
			$field.find( '.umbrcom-media-choose-file' ).text( 'החלפת קובץ' );
			$field.find( '.umbrcom-media-remove' ).show();
		} );
		frame.open();
	} );

	$( document ).on( 'click', '.umbrcom-media-remove', function ( e ) {
		e.preventDefault();
		var $field = $( this ).closest( '.umbrcom-media-field' );
		$field.find( '.umbrcom-media-value' ).val( '' );
		$field.find( '.umbrcom-media-preview' ).hide();
		$field.find( '.umbrcom-media-filename' ).text( '' );
		$field.find( '.umbrcom-media-choose' ).text( 'בחירת תמונה' );
		$field.find( '.umbrcom-media-choose-file' ).text( 'בחירת קובץ' );
		$( this ).hide();
	} );

	/* ── Relationship: search-as-you-type + pill picker ── */

	var searchTimer = null;

	$( document ).on( 'input', '.umbrcom-relationship-search', function () {
		var $input   = $( this );
		var $wrap    = $input.closest( '.umbrcom-relationship' );
		var $results = $wrap.find( '.umbrcom-relationship-results' );
		var term     = $input.val();

		clearTimeout( searchTimer );
		if ( term.length < 2 ) {
			$results.empty().hide();
			return;
		}

		searchTimer = setTimeout( function () {
			$.get( UmbrcomCE.ajaxUrl, {
				action: 'umbrcom_search_posts',
				nonce: UmbrcomCE.nonce,
				search: term,
				post_type: $wrap.attr( 'data-post-type' ),
			}, function ( items ) {
				var selectedIds = $wrap.find( '.umbrcom-pill input[type=hidden]' ).map( function () {
					return String( $( this ).val() );
				} ).get();

				$results.empty();
				if ( ! items || ! items.length ) {
					$results.hide();
					return;
				}
				items.forEach( function ( item ) {
					if ( selectedIds.indexOf( String( item.id ) ) !== -1 ) {
						return;
					}
					$( '<div class="umbrcom-relationship-result"></div>' )
						.text( item.title )
						.attr( 'data-id', item.id )
						.appendTo( $results );
				} );
				$results.show();
			} );
		}, 300 );
	} );

	$( document ).on( 'click', '.umbrcom-relationship-result', function () {
		var $result = $( this );
		var $wrap   = $result.closest( '.umbrcom-relationship' );
		var name    = $wrap.attr( 'data-name' );
		var id      = $result.attr( 'data-id' );
		var title   = $result.text();

		var $pill = $( '<span class="umbrcom-pill"></span>' );
		$pill.append( $( '<input type="hidden">' ).attr( 'name', name + '[]' ).val( id ) );
		$pill.append( document.createTextNode( title ) );
		$pill.append( $( '<button type="button" class="umbrcom-pill-remove">&times;</button>' ) );

		$wrap.find( '.umbrcom-relationship-pills' ).append( $pill );
		$wrap.find( '.umbrcom-relationship-search' ).val( '' );
		$wrap.find( '.umbrcom-relationship-results' ).empty().hide();
	} );

	$( document ).on( 'click', '.umbrcom-pill-remove', function () {
		$( this ).closest( '.umbrcom-pill' ).remove();
	} );

	/* ── Init on load ── */

	$( function () {
		initColorPickers( $( document ) );
	} );

})( jQuery );
