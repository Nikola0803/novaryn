<?php
/**
 * "Storefront Details" meta box on every WooCommerce product — the fields
 * WooCommerce doesn't have natively: spec table, 3D model, AR toggle,
 * badges, curated related accessories.
 *
 * Colors/finishes are NOT here — those use WooCommerce's native
 * Attributes + Variations, which is the correct WooCommerce-native way to
 * do "same product, different finish" (see SETUP.md).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Umbrcom_CE_Product_Fields_Metabox {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_product', array( __CLASS__, 'save' ) );
	}

	public static function add_meta_box() {
		add_meta_box( 'umbrcom_product_fields', 'פרטי המוצר בחנות', array( __CLASS__, 'render' ), 'product', 'normal', 'high' );
	}

	public static function render( $post ) {
		wp_nonce_field( 'umbrcom_product_save', 'umbrcom_product_nonce' );

		$brand_label  = get_post_meta( $post->ID, '_umbrcom_brand_label', true ) ?: 'Waterfall';
		$feature_cards = get_post_meta( $post->ID, '_umbrcom_feature_cards', true ) ?: array();
		$short_desc   = get_post_meta( $post->ID, '_umbrcom_short_description', true );
		$paragraphs   = get_post_meta( $post->ID, '_umbrcom_description_paragraphs', true ) ?: array();
		$features     = get_post_meta( $post->ID, '_umbrcom_features', true ) ?: array();
		$specs        = get_post_meta( $post->ID, '_umbrcom_spec_table', true ) ?: array();
		$shipping     = get_post_meta( $post->ID, '_umbrcom_shipping_info', true ) ?: array();
		$model_3d     = get_post_meta( $post->ID, '_umbrcom_model_3d_url', true );
		$model_usdz   = get_post_meta( $post->ID, '_umbrcom_model_usdz_url', true );
		$ar_enabled   = get_post_meta( $post->ID, '_umbrcom_ar_enabled', true );
		$youtube_url  = get_post_meta( $post->ID, '_umbrcom_youtube_url', true );
		$ai_review    = get_post_meta( $post->ID, '_umbrcom_ai_review', true );
		$tech_specs   = get_post_meta( $post->ID, '_umbrcom_tech_specs_html', true );
		$package      = get_post_meta( $post->ID, '_umbrcom_package_contents', true );
		if ( is_array( $package ) ) { // legacy repeater format → one item per line
			$package = implode( "\n", array_filter( wp_list_pluck( $package, 'text' ) ) );
		}
		$warranty     = get_post_meta( $post->ID, '_umbrcom_warranty', true );
		$badge        = get_post_meta( $post->ID, '_umbrcom_badge_text', true );
		$is_new       = get_post_meta( $post->ID, '_umbrcom_is_new', true );
		$accessories  = get_post_meta( $post->ID, '_umbrcom_related_accessories', true ) ?: array();

		echo '<div class="umbrcom-rtl">';
		echo '<h4>כותרת</h4>';
		Umbrcom_Fields::text( 'umbrcom_brand_label', $brand_label, 'תווית מותג (מוצגת כ־"— Waterfall" ליד הקטגוריה)' );

		echo '<h4>כרטיסיות מידע (3 הכרטיסיות עם אייקונים מעל אזור הרכישה)</h4>';
		Umbrcom_Fields::repeater(
			'umbrcom_feature_cards',
			$feature_cards,
			function ( $base, $i, $row ) {
				Umbrcom_Fields::text( "{$base}[{$i}][icon]", $row['icon'] ?? '', 'מחלקת אייקון Remix' );
				Umbrcom_Fields::text( "{$base}[{$i}][title]", $row['title'] ?? '', 'כותרת' );
				Umbrcom_Fields::text( "{$base}[{$i}][sub]", $row['sub'] ?? '', 'כותרת משנה' );
			},
			'+ הוספת כרטיסייה',
			'__L1_INDEX__'
		);

		echo '<h4>תיאור קצר (השורה המודגשת ליד המק"ט)</h4>';
		Umbrcom_Fields::textarea( 'umbrcom_short_description', $short_desc, '', 2 );

		echo '<h4>לשונית תיאור</h4>';
		Umbrcom_Fields::repeater(
			'umbrcom_description_paragraphs',
			$paragraphs,
			function ( $base, $i, $row ) {
				Umbrcom_Fields::textarea( "{$base}[{$i}][text]", $row['text'] ?? '', 'פסקה', 2 );
			},
			'+ הוספת פסקה',
			'__L1_INDEX__'
		);
		Umbrcom_Fields::repeater(
			'umbrcom_features',
			$features,
			function ( $base, $i, $row ) {
				Umbrcom_Fields::text( "{$base}[{$i}][text]", $row['text'] ?? '', 'נקודת תכונה' );
			},
			'+ הוספת נקודת תכונה',
			'__L1_INDEX__'
		);

		echo '<h4>נתונים טכניים — שורות תווית/ערך (חלופה פשוטה)</h4>';
		echo '<p class="description">מוצגות בעמוד המוצר רק אם שדה "נתונים טכניים" (עורך ויזואלי) שבהמשך ריק.</p>';
		Umbrcom_Fields::excel_paste_zone();
		Umbrcom_Fields::repeater(
			'umbrcom_spec_table',
			$specs,
			function ( $base, $i, $row ) {
				Umbrcom_Fields::text( "{$base}[{$i}][label]", $row['label'] ?? '', 'תווית', 'חומר' );
				Umbrcom_Fields::text( "{$base}[{$i}][value]", $row['value'] ?? '', 'ערך', 'פליז עם ציפוי פרמיום' );
			},
			'+ הוספת שורת מפרט',
			'__L1_INDEX__'
		);

		echo '<h4>סרטון מוצר</h4>';
		Umbrcom_Fields::url( 'umbrcom_youtube_url', $youtube_url, 'הדביקו קישור YouTube (בכל פורמט — ‎watch?v=‎, youtu.be או Shorts). אם מולא — הסרטון מוטמע ומוצג בעמוד המוצר תחת "סרטון מוצר".' );

		echo '<h4>סקירת AI</h4>';
		Umbrcom_Fields::wysiwyg( 'umbrcom_ai_review', $ai_review, 'סקירת מוצר שנוצרה ב־AI — עורך ויזואלי. מוצג בעמוד המוצר תחת "סקירת AI".' );

		echo '<h4>נתונים טכניים</h4>';
		Umbrcom_Fields::wysiwyg( 'umbrcom_tech_specs_html', $tech_specs, 'נתונים טכניים — עורך ויזואלי. הדביקו טבלה ישירות מאקסל והיא נשמרת כטבלה מעוצבת. מוצג תחת "נתונים טכניים".', 260 );

		echo '<h4>תכולת האריזה</h4>';
		Umbrcom_Fields::textarea( 'umbrcom_package_contents', $package, 'טקסט חופשי — פריט אחד בכל שורה (למשל: ברז, ערכת התקנה, צינורות חיבור…). מוצג כרשימה תחת "תכולת האריזה".', 5 );

		echo '<h4>אחריות</h4>';
		Umbrcom_Fields::wysiwyg( 'umbrcom_warranty', $warranty, 'תנאי האחריות — עורך ויזואלי. מוצג בעמוד המוצר תחת "אחריות".', 160 );

		echo '<h4>לשונית משלוח / החזרות / אחריות</h4>';
		Umbrcom_Fields::repeater(
			'umbrcom_shipping_info',
			$shipping,
			function ( $base, $i, $row ) {
				Umbrcom_Fields::text( "{$base}[{$i}][icon]", $row['icon'] ?? '', 'מחלקת אייקון Remix' );
				Umbrcom_Fields::text( "{$base}[{$i}][title]", $row['title'] ?? '', 'כותרת' );
				Umbrcom_Fields::textarea( "{$base}[{$i}][text]", $row['text'] ?? '', 'טקסט', 2 );
			},
			'+ הוספת בלוק',
			'__L1_INDEX__'
		);

		echo '<h4>תלת־ממד / AR</h4>';
		Umbrcom_Fields::file( 'umbrcom_model_3d_url', $model_3d, 'קובץ מודל תלת־ממד (‎.glb — אנדרואיד/דפדפן)', 'model/gltf-binary' );
		Umbrcom_Fields::file( 'umbrcom_model_usdz_url', $model_usdz, 'קובץ מודל תלת־ממד — ‎iOS AR (.usdz)', '' );
		Umbrcom_Fields::checkbox( 'umbrcom_ar_enabled', $ar_enabled === '1', 'הצגת כפתור "צפייה בתלת־ממד / AR" בעמוד המוצר' );

		echo '<h4>תגיות ואביזרים</h4>';
		Umbrcom_Fields::text( 'umbrcom_badge_text', $badge, 'טקסט תגית מותאם אישית (דורס את תגית "מבצע" האוטומטית)' );
		Umbrcom_Fields::checkbox( 'umbrcom_is_new', $is_new === '1', 'סימון המוצר כ"חדש"' );
		Umbrcom_Fields::relationship( 'umbrcom_related_accessories', $accessories, 'product', 'אביזרים מומלצים / מוצרים קשורים (השאירו ריק כדי להשתמש אוטומטית במוצרים מאותה קטגוריה)' );

		echo '<p class="description" style="margin-top:16px">צבעים/גימורים, מחיר, מחיר מבצע, מלאי, גלריית תמונות וחוות דעת אינם כאן — הם מנוהלים בשדות המובנים של WooCommerce (מאפיינים/וריאציות, נתוני מוצר, גלריית מוצר וחוות דעת) למעלה במסך זה.</p>';
		echo '</div>';
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['umbrcom_product_nonce'] ) || ! wp_verify_nonce( $_POST['umbrcom_product_nonce'], 'umbrcom_product_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_umbrcom_brand_label', sanitize_text_field( wp_unslash( $_POST['umbrcom_brand_label'] ?? '' ) ) );

		update_post_meta( $post_id, '_umbrcom_feature_cards', self::sanitize_rows( $_POST['umbrcom_feature_cards'] ?? array(), array( 'icon', 'title', 'sub' ) ) );

		update_post_meta( $post_id, '_umbrcom_short_description', sanitize_textarea_field( wp_unslash( $_POST['umbrcom_short_description'] ?? '' ) ) );

		update_post_meta( $post_id, '_umbrcom_description_paragraphs', self::sanitize_rows( $_POST['umbrcom_description_paragraphs'] ?? array(), array( 'text' ), true ) );
		update_post_meta( $post_id, '_umbrcom_features', self::sanitize_rows( $_POST['umbrcom_features'] ?? array(), array( 'text' ) ) );
		update_post_meta( $post_id, '_umbrcom_spec_table', self::sanitize_rows( $_POST['umbrcom_spec_table'] ?? array(), array( 'label', 'value' ) ) );
		update_post_meta( $post_id, '_umbrcom_shipping_info', self::sanitize_rows( $_POST['umbrcom_shipping_info'] ?? array(), array( 'icon', 'title', 'text' ), true ) );

		update_post_meta( $post_id, '_umbrcom_youtube_url', esc_url_raw( wp_unslash( $_POST['umbrcom_youtube_url'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_ai_review', wp_kses_post( wp_unslash( $_POST['umbrcom_ai_review'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_tech_specs_html', self::sanitize_tech_specs( wp_unslash( $_POST['umbrcom_tech_specs_html'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_package_contents', sanitize_textarea_field( wp_unslash( $_POST['umbrcom_package_contents'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_warranty', wp_kses_post( wp_unslash( $_POST['umbrcom_warranty'] ?? '' ) ) );

		update_post_meta( $post_id, '_umbrcom_model_3d_url', absint( $_POST['umbrcom_model_3d_url'] ?? 0 ) );
		update_post_meta( $post_id, '_umbrcom_model_usdz_url', absint( $_POST['umbrcom_model_usdz_url'] ?? 0 ) );
		update_post_meta( $post_id, '_umbrcom_ar_enabled', ! empty( $_POST['umbrcom_ar_enabled'] ) ? '1' : '0' );
		update_post_meta( $post_id, '_umbrcom_badge_text', sanitize_text_field( wp_unslash( $_POST['umbrcom_badge_text'] ?? '' ) ) );
		update_post_meta( $post_id, '_umbrcom_is_new', ! empty( $_POST['umbrcom_is_new'] ) ? '1' : '0' );
		update_post_meta( $post_id, '_umbrcom_related_accessories', array_map( 'absint', (array) ( $_POST['umbrcom_related_accessories'] ?? array() ) ) );
	}

	/**
	 * "נתונים טכניים" — accepts either HTML (a <table> etc.) or a raw
	 * Excel paste. Pasting cells from Excel/Sheets into a textarea produces
	 * tab-separated lines, so when there's no <table> but tabs are present,
	 * the paste is converted into a proper HTML table (first row = header).
	 * Either way the result is passed through a strict wp_kses allowlist,
	 * so the stored HTML is safe to render on the storefront as-is.
	 */
	private static function sanitize_tech_specs( $raw ) {
		$raw = (string) $raw;
		if ( trim( $raw ) === '' ) {
			return '';
		}

		if ( stripos( $raw, '<table' ) === false && strpos( $raw, "\t" ) !== false ) {
			$lines = preg_split( '/\r\n|\r|\n/', trim( $raw ) );
			$html  = '<table><tbody>';
			foreach ( $lines as $li => $line ) {
				if ( trim( $line ) === '' ) {
					continue;
				}
				$cells = explode( "\t", $line );
				$tag   = $li === 0 ? 'th' : 'td';
				$html .= '<tr>';
				foreach ( $cells as $cell ) {
					$html .= '<' . $tag . '>' . esc_html( trim( $cell ) ) . '</' . $tag . '>';
				}
				$html .= '</tr>';
			}
			$html .= '</tbody></table>';
			$raw   = $html;
		}

		$allowed = array(
			'table' => array(), 'thead' => array(), 'tbody' => array(),
			'tr'    => array(),
			'th'    => array( 'colspan' => true, 'rowspan' => true ),
			'td'    => array( 'colspan' => true, 'rowspan' => true ),
			'p'     => array(), 'br' => array(), 'span' => array(),
			'b'     => array(), 'strong' => array(), 'i' => array(), 'em' => array(),
			'ul'    => array(), 'ol' => array(), 'li' => array(),
			'h3'    => array(), 'h4' => array(),
			'a'     => array( 'href' => true, 'target' => true, 'rel' => true ),
		);
		return wp_kses( $raw, $allowed );
	}

	/** Sanitizes a repeater's rows generically: trims each named field with
	 *  sanitize_text_field (or sanitize_textarea_field if $multiline), and
	 *  drops fully-empty rows. */
	private static function sanitize_rows( $raw, array $fields, $multiline = false ) {
		$raw = is_array( $raw ) ? wp_unslash( $raw ) : array();
		$out = array();
		foreach ( $raw as $row ) {
			$clean_row = array();
			$has_value = false;
			foreach ( $fields as $f ) {
				$val = $multiline ? sanitize_textarea_field( $row[ $f ] ?? '' ) : sanitize_text_field( $row[ $f ] ?? '' );
				$clean_row[ $f ] = $val;
				if ( $val !== '' ) {
					$has_value = true;
				}
			}
			if ( $has_value ) {
				$out[] = $clean_row;
			}
		}
		return $out;
	}
}
